-- SPDX-License-Identifier: 0BSD
import BeaconcryptCore.Computational.PqxdhRegistrationTailEvents

/-! The actual completed response callback and its private source events inside the complete constructed nine-capability canonical schedule. -/
open OracleComp OracleSpec CoreModels Aeneas
open Aeneas.Std hiding namespace core alloc
open RustM beaconcrypt_core PqxdhRefinement
set_option autoImplicit false
namespace BeaconcryptCore.Computational.PqxdhRegistrationTailEventRun
open PqxdhRegistrationSerialTrace PqxdhRegistrationProcessControl
open PqxdhRegistrationTailEvents PqxdhRegistrationTailCallback PqxdhServerRegistrationPublication
open PqxdhJointIdentity PqxdhJointGapDh PqxdhServerAuthExperiment PqxdhServerAuthNative
variable {ι KemSK Reader WireResponse : Type} {baseSpec : OracleSpec ι}

/-- Execute the same complete response callback once and expose its reached source events only to private analysis. Every primitive, writer, erase and native-state effect remains in the underlying callback. -/
noncomputable def observed {A : Type} (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse)
    (checks : Checks) (index : Nat) (payload : Option Pqxdh.Bytes) (encoded : Pqxdh.Bytes)
    (before : PqxdhRegistrationTableDispatcher.State KemSK A) :
    ProbComp ((Option Response × List PqxdhRegistrationTailEvents.Event) × PqxdhRegistrationTableDispatcher.State KemSK A) :=
  (fun result => ((result.1.1, events result.1.1 result.1.2), result.2)) <$>
    PqxdhRegistrationTailCallback.build setup codec checks index payload encoded before

/-- Removing the private event list recovers the complete source-value callback, including its full returned state and every optional refusal. -/
theorem observed_erase {A : Type} (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse)
    (checks : Checks) (index : Nat) (payload : Option Pqxdh.Bytes) (encoded : Pqxdh.Bytes)
    (before : PqxdhRegistrationTableDispatcher.State KemSK A) :
    (fun result => (result.1.1, result.2)) <$> observed setup codec checks index payload encoded before =
      PqxdhRegistrationPayloadProcess.build setup codec checks index payload encoded before := by
  simpa only [observed, Functor.map_map] using
    PqxdhRegistrationTailCallback.build_erase setup codec checks index payload encoded before

/-- Private event observation preserves every complete continuation on the original public reply and full state, not only the marginal callback result. -/
theorem observed_continue {A Result : Type} (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse)
    (checks : Checks) (index : Nat) (payload : Option Pqxdh.Bytes) (encoded : Pqxdh.Bytes)
    (before : PqxdhRegistrationTableDispatcher.State KemSK A)
    (next : Option Response → PqxdhRegistrationTableDispatcher.State KemSK A → ProbComp Result) :
    (observed setup codec checks index payload encoded before >>= fun result => next result.1.1 result.2) =
      (PqxdhRegistrationPayloadProcess.build setup codec checks index payload encoded before >>=
        fun result => next result.1 result.2) := by
  rw [← observed_erase, bind_map_left]

/-- Every observed completion has its literal source receipt, exact publication list, and unique public completion, including native diagnostics and absent-token refusal. -/
theorem observed_receipt {A : Type} (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse)
    (checks : Checks) (index : Nat) (payload : Option Pqxdh.Bytes) (encoded : Pqxdh.Bytes)
    (before after : PqxdhRegistrationTableDispatcher.State KemSK A) (reply : Option Response)
    (trace : List PqxdhRegistrationTailEvents.Event)
    (supported : ((reply, trace), after) ∈ support (observed setup codec checks index payload encoded before)) :
    ∃ receipt,
      ((reply, receipt), after) ∈ support (PqxdhRegistrationTailCallback.build setup codec checks index payload encoded before) ∧
      trace = events reply receipt ∧ CallRelation before index payload reply receipt after ∧
      trace.filterMap PqxdhRegistrationTailEvents.Event.publication = reply.toList ∧
      trace.filterMap PqxdhRegistrationTailEvents.Event.terminal =
        (if reply.isSome then [] else [Sum.inl (receipt.map CallReceipt.receipt)]) ++ [Sum.inr reply] := by
  simp only [observed, support_map, Set.mem_image] at supported
  obtain ⟨⟨⟨actualReply, receipt⟩, actualState⟩, supported, equal⟩ := supported
  obtain ⟨⟨rfl, rfl⟩, rfl⟩ := Prod.mk.inj equal |>.imp Prod.mk.inj id
  exact ⟨receipt, supported, rfl,
    build_relation setup codec checks index payload encoded before actualReply receipt actualState supported,
    events_publications before index payload actualReply receipt actualState
      (build_relation setup codec checks index payload encoded before actualReply receipt actualState supported),
    events_terminals actualReply receipt⟩

/-- Extend the existing concrete source trace by one complete callback, without changing any earlier callback or reply. -/
private theorem calls_snoc {κ S : Type} {spec : OracleSpec κ}
    (impl : QueryImpl spec (StateT S ProbComp)) (before middle after : S) (journal : QueryLog spec)
    (earlier : Calls impl before journal middle) (query : spec.Domain) (reply : spec.Range query)
    (supported : (reply, after) ∈ support ((impl query).run middle)) :
    Calls impl before (journal ++ [⟨query, reply⟩]) after := by
  induction earlier with
  | nil state => exact Calls.cons query reply state after after [] supported (Calls.nil after)
  | cons first firstReply start next final rest reached tail ih =>
      exact Calls.cons first firstReply start next after _ reached (ih supported)

/-- The actual supplied/generated Server constructor and complete adaptive prefix supply the canonical run in which this response callback completes. Every prior public reply and full intermediate state remains in the trace; the private publication events are exactly this callback's actual return. -/
theorem prefix_events {A Result : Type} (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse)
    (checks : Checks) (ensureInit : StateT A ProbComp Bool) (supplied : Option Pqxdh.Bytes)
    (adversary : PublicIdentity → U64 → OracleComp PqxdhRegistrationSchedule.SurfaceSpec Result)
    (runtime afterRuntime : A) (created : PqxdhLiveServerConstruction.Created Unit)
    (answer : Result) (journal : QueryLog PqxdhRegistrationSchedule.SurfaceSpec)
    (state : PqxdhRegistrationSchedule.State KemSK) (table : PqxdhRegistrationPendingTables.PendingTable)
    (reached : (some (created, (answer, journal), state, table), afterRuntime) ∈ support
      (PqxdhRegistrationTableDispatcher.experiment setup codec checks ensureInit supplied
        (fun identity sender => PqxdhRegistrationCells.journal (adversary identity sender)) runtime))
    (index : Nat) (payload : Option Pqxdh.Bytes) (reply : Option Response)
    (after : PqxdhRegistrationTableDispatcher.State KemSK A)
    (supported : (reply, after) ∈ support
      ((PqxdhRegistrationTableDispatcher.handler setup codec checks created.seed ensureInit
        (PqxdhRegistrationBuildLookup.buildQuery index payload)).run ((afterRuntime, state), table))) :
    ∃ initializedRuntime,
      (some created, initializedRuntime) ∈ support
        ((PqxdhLiveServerConstruction.construct setup.joint ensureInit 0 setup.serverKeyId supplied).run runtime) ∧
      ∃ encoded receipt,
        ((reply, receipt), after) ∈ support (PqxdhRegistrationTailCallback.build setup codec checks
          index payload encoded ((afterRuntime, state), table)) ∧
        CallRelation ((afterRuntime, state), table) index payload reply receipt after ∧
        (events reply receipt).filterMap Event.publication = reply.toList ∧
        Run program (PqxdhRegistrationTableDispatcher.handler setup codec checks created.seed ensureInit)
          ⟨PqxdhRegistrationTableDispatcher.initial created initializedRuntime, .idle, []⟩
          (journal ++ [⟨PqxdhRegistrationBuildLookup.buildQuery index payload, reply⟩])
          (4 * (journal.length + 1)) ⟨after, .idle, []⟩ ∧
        (PqxdhRegistrationTailCallback.build setup codec checks index payload encoded
          ((afterRuntime, state), table)).IsTotalQueryBound 64 := by
  obtain ⟨encoded, receipt, observed, related, published, _, bounded⟩ :=
    PqxdhRegistrationTailEvents.callback_run setup codec checks ensureInit supplied
      (fun identity sender => PqxdhRegistrationCells.journal (adversary identity sender))
      runtime afterRuntime created (answer, journal) state table reached index payload reply after supported
  simp only [PqxdhRegistrationTableDispatcher.experiment, mem_support_bind_iff] at reached
  rcases reached with ⟨⟨_ | started, initialized⟩, born, continued⟩
  all_goals simp [Set.mem_image] at continued
  obtain ⟨continued, rfl⟩ := continued
  refine ⟨initialized, born, encoded, receipt, observed, related, published, ?_, bounded⟩
  have earlier := PqxdhRegistrationSerialTrace.journal_calls
    (PqxdhRegistrationTableDispatcher.handler setup codec checks started.seed ensureInit)
    (adversary started.publicIdentity started.server.server.metadata.sender)
    (PqxdhRegistrationTableDispatcher.initial started initialized) ((afterRuntime, state), table)
    answer journal continued
  simpa only [List.length_append, List.length_singleton] using
    (PqxdhRegistrationProcessControl.calls_run _ program_wrapper _ _ _ _
      (calls_snoc _ _ _ _ _ earlier _ _ supported))

/-- Actual constructor and arbitrary nine-capability history supply a private field witness for the eventful callback. Every complete continuation on the original reply and full state is unchanged, and the callback retains its complete source uniform allowance. -/
theorem table_continue {A Result : Type} (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse)
    (checks : Checks) (ensureInit : StateT A ProbComp Bool) (supplied : Option Pqxdh.Bytes)
    (adversary : PublicIdentity → U64 → OracleComp PqxdhRegistrationSchedule.SurfaceSpec Result)
    (runtime afterRuntime : A) (created : PqxdhLiveServerConstruction.Created Unit)
    (answer : Result) (state : PqxdhRegistrationSchedule.State KemSK)
    (table : PqxdhRegistrationPendingTables.PendingTable)
    (reached : (some (created, answer, state, table), afterRuntime) ∈ support
      (PqxdhRegistrationTableDispatcher.experiment setup codec checks ensureInit supplied adversary runtime))
    (index : Nat) (payload : Option Pqxdh.Bytes) :
    ∃ encoded,
      (observed setup codec checks index payload encoded ((afterRuntime, state), table)).IsTotalQueryBound 64 ∧
      ∀ (Output : Type) (next : Option Response → PqxdhRegistrationTableDispatcher.State KemSK A → ProbComp Output),
        (observed setup codec checks index payload encoded ((afterRuntime, state), table) >>=
          fun result => next result.1.1 result.2) =
        ((PqxdhRegistrationTableDispatcher.handler setup codec checks created.seed ensureInit
          (PqxdhRegistrationBuildLookup.buildQuery index payload)).run ((afterRuntime, state), table) >>=
          fun result => next result.1 result.2) := by
  obtain ⟨encoded, same, bounded⟩ := PqxdhRegistrationTailCallback.table_callback setup codec checks ensureInit
    supplied adversary runtime afterRuntime created answer state table reached index payload
  refine ⟨encoded, by simpa only [observed, IsTotalQueryBound, isQueryBound_map_iff] using bounded, ?_⟩
  intro Output next
  simp only [← same, observed, bind_map_left]
  change (PqxdhRegistrationTailCallback.build setup codec checks index payload encoded ((afterRuntime, state), table) >>=
      fun result => next result.1.1 result.2) =
    (((fun result => (result.1.1, result.2)) <$>
      PqxdhRegistrationTailCallback.build setup codec checks index payload encoded ((afterRuntime, state), table)) >>=
      fun result => next result.1 result.2)
  rw [bind_map_left]

end BeaconcryptCore.Computational.PqxdhRegistrationTailEventRun

/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailEventRun.observed_erase' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailEventRun.observed_erase
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailEventRun.observed_continue' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailEventRun.observed_continue
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailEventRun.observed_receipt' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailEventRun.observed_receipt
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailEventRun.prefix_events' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailEventRun.prefix_events
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailEventRun.table_continue' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailEventRun.table_continue
