# Scoped modulo equivalence review

The raw mutant `beaconcrypt/examples/persistence_bench/main.rs:850:79: replace % with + in run_serial` remains recorded as `MissedMutant`. This note requests scoped equivalence classification; it does not claim the mutant was caught or is equivalent for all `usize` values.

Let `S = trial - 1 + peer_index + scenario_index + direction_index`, and let `o = pair_order`, with `0 <= o <= 2`. The original code selects `(S % 3 + o) % 3`. The mutation changes the earlier reduction into addition, selecting `(S + 3 + o) % 3`. These select the same arm whenever the constituent arithmetic and `S + 3 + o` fit `usize`, because adding a multiple of three does not change a remainder modulo three. `first` has no other use or observable report field.

The full serial report tests use three trials, two peer axes, five scenarios and two directions. Thus `S <= 2 + 1 + 4 + 1 = 8` and `S + 3 + o <= 13`. The default serial configuration uses three trials, three peer axes, six scenarios and two directions, giving `S <= 10` and the latter sum at most 15.

The predeclared concurrent collection preparer fixes `--mode concurrent`, so this serial expression is not reached in that collection. Its per-axis arguments have three trials, one peer axis per invocation and three burst scenarios plus three stream scenarios. If those same arguments were executed through serial mode, the corresponding bound would again be `S <= 8` and `S + 3 + o <= 13`. The preparation-source hash is included in the JSON evidence; the final collection-plan binding remains to be checked when that plan is frozen.

No equivalence is asserted for arbitrary CLI trial counts or arbitrary `usize` inputs near overflow. No claim about infeasible allocations, elapsed execution time, or report growth is used to exclude those cases. The mutation, exact catalog entry, full successful 59-test outcome and their hashes are preserved in scoped-equivalence.json and the raw audit artifacts. Parent review is required before this receives a final scoped-equivalence label.

Parent review accepted the bounded scopes above while retaining the raw missed outcome. The exact frozen collection-plan hash is still pending; no global equivalence was accepted.
