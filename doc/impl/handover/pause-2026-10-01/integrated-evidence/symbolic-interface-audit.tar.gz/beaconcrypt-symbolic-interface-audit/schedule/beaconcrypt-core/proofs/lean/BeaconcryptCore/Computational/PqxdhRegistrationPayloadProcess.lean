-- SPDX-License-Identifier: 0BSD
import BeaconcryptCore.Computational.PqxdhRegistrationResponseEncoding

/-! Interpret the existing response identifier/binding/payload fragment on its bounded source image, through the complete native table callback. This does not interpret unrelated symbolic constructors or arbitrary applied-pi traces. -/
open OracleComp OracleSpec CoreModels Aeneas
open Aeneas.Std hiding namespace core alloc
open RustM beaconcrypt_core PqxdhRefinement
set_option autoImplicit false
namespace BeaconcryptCore.Computational.PqxdhRegistrationPayloadProcess
open PqxdhServerRegistrationPublication PqxdhRegistrationResponseEncoding

/-- The existing publicly constructible numeric identifier declaration. -/
def identifierDeclaration : String := "fun registration_response_identifier(nat): key_id [data].\n"

/-- The three actual response expressions whose source interpretation is the typed U64 prefix followed by the original plaintext. -/
def bindingFragment : String := r#"let assigned = registration_response_identifier(next) in
            let binding = beaconcrypt_core__pqxdh__RegistrationKeyIdBinding(key_id_encoding(assigned)) in
            let authenticated = registration_payload(binding, plaintext) in"#

/-- The existing public key-identifier encoding interface interpreted on U64 values. -/
def encodingDeclaration : String := r#"fun sender_id_le64(key_id): bitstring [data].
letfun key_id_encoding(identifier: key_id) = sender_id_le64(identifier).
"#

/-- The existing payload constructor interpreted only at the source binding/payload sort. Global byte-to-term disjointness is not asserted. -/
def payloadDeclaration : String := r#"fun registration_payload(
  beaconcrypt_core__pqxdh__t_RegistrationKeyIdBinding,
  bitstring
): bitstring [data].
"#

/-- The complete counter/peer/identity response path, with the reached binding expressions interpreted by their actual byte encoding. Every remaining native callback and failure is retained. -/
noncomputable def response {Metadata PeerMetadata Consumed : Type}
    (source : PqxdhJointKdfGame.FixedHkdfSha512NoSaltSource)
    (pending : pqxdh.PendingServerRegistration) (encoded : Pqxdh.Bytes)
    (root : PqxdhSecretInputKdf.RootOutput) (data : Option Pqxdh.Bytes)
    (metadata : PeerMetadata) (state : State Metadata PeerMetadata Consumed) :
    OracleComp TailSpec (RustM (Option Response × State Metadata PeerMetadata Consumed)) :=
  match PqxdhRegistrationBuildCounter.successor state.control.last_key_id with
  | none => pure (ok (none, state))
  | some next =>
      if (state.server.peers next).isSome then pure (ok (none, state)) else
        match PqxdhEd25519EufCma.parseIdentity encoded with
        | none => pure (ok (none, state))
        | some identity => continueRust
            (PqxdhRegistrationBuildCounter.candidate state.control
              { pending with beacon_identity_public_key := PqxdhRootTableInitialization.rootArray identity }
              ⟨state.server.identity, state.identityKeyId⟩ next) fun candidate =>
                encodedTail source candidate root data metadata state

/-- Concrete source encoding preserves the entire previous identity interpreter without a field, success or writer premise. -/
theorem response_identity {Metadata PeerMetadata Consumed : Type}
    (source : PqxdhJointKdfGame.FixedHkdfSha512NoSaltSource)
    (pending : pqxdh.PendingServerRegistration) (encoded : Pqxdh.Bytes)
    (root : PqxdhSecretInputKdf.RootOutput) (data : Option Pqxdh.Bytes)
    (metadata : PeerMetadata) (state : State Metadata PeerMetadata Consumed) :
    response source pending encoded root data metadata state =
      PqxdhRegistrationIdentityProcess.interpret source pending encoded root data metadata state
        PqxdhRegistrationCounterProcess.response none := by
  simp only [response, PqxdhRegistrationCounterProcess.response, PqxdhRegistrationIdentityProcess.interpret,
    PqxdhRegistrationIdentityProcess.identityTail, candidate_encoding]
  rfl

open PqxdhJointIdentity PqxdhJointGapDh PqxdhServerAuthExperiment PqxdhServerAuthNative
variable {ι KemSK Reader Response : Type} {baseSpec : OracleSpec ι}

/-- The actual evaluated present-token callback with the concrete symbolic-value interpretation above. Disposal, caches and successful-seal observations are unchanged even when either writer fails. -/
noncomputable def present (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (session : Nat) (payload : Option Pqxdh.Bytes)
    (token : PqxdhServerRelatedRootConsumer.Returned) (encoded : Pqxdh.Bytes) (state : NativeState KemSK) :
    ProbComp (Option PqxdhServerRegistrationPublication.Response × NativeState KemSK) :=
  (fun result =>
    let settled := settle state.2.server result.1
    (settled.1, state.1, { state.2 with
      pending := Function.update state.2.pending session none
      server := settled.2
      ctx := result.2.2
      ghost := { state.2.ghost with seals := state.2.ghost.seals ++ result.2.1.map (fun context => (session, context)) } })) <$>
    (simulateQ (tailImpl setup codec checks)
      (response setup.source token.pending encoded token.root payload () state.2.server)).run
        ([], state.2.ctx)

/-- Equality is of the full optional reply and native/private/cache poststate, not a marginal payload or successful branch. -/
theorem present_identity (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (session : Nat) (payload : Option Pqxdh.Bytes)
    (token : PqxdhServerRelatedRootConsumer.Returned) (encoded : Pqxdh.Bytes) (state : NativeState KemSK) :
    present setup codec checks session payload token encoded state =
      PqxdhRegistrationIdentityProcess.present setup codec checks session payload token encoded state := by
  simp only [present, response_identity, PqxdhRegistrationIdentityProcess.present]

/-- The complete numeric table dispatcher reaches the interpreted fragment only for an available token, consuming it before the callback. Missing, future and spent handles still reject normally. -/
noncomputable def build {A : Type} (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (session : Nat) (payload : Option Pqxdh.Bytes) (encoded : Pqxdh.Bytes)
    (state : PqxdhRegistrationTableDispatcher.State KemSK A) :
    ProbComp (Option PqxdhServerRegistrationPublication.Response × PqxdhRegistrationTableDispatcher.State KemSK A) :=
  let restored := PqxdhRegistrationTableDispatcher.restore state
  match PqxdhRegistrationBuildLookup.available state.2 session with
  | none => pure (none, PqxdhRegistrationTableDispatcher.clear state)
  | some token =>
      let consumed := state.2.consume session
      (fun result => (result.1, PqxdhRegistrationTableDispatcher.clear
        ((restored.1, { restored.2 with shared := result.2 }), consumed))) <$>
        present setup codec checks session payload token encoded (PqxdhRegistrationBuildLookup.dispose restored.2.shared session)

/-- The actual binding/payload interpretation retains the entire existing table operation on arbitrary supplied states. -/
theorem build_identity {A : Type} (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (session : Nat) (payload : Option Pqxdh.Bytes) (encoded : Pqxdh.Bytes)
    (state : PqxdhRegistrationTableDispatcher.State KemSK A) :
    build setup codec checks session payload encoded state =
      PqxdhRegistrationIdentityProcess.build setup codec checks session payload encoded state := by
  simp only [build, PqxdhRegistrationIdentityProcess.build, present_identity]
  rfl

/-- The literal supplied/generated Server constructor and entire adaptive schedule supply the private field witness for this complete callback interpretation. The original uniform64 bill includes every reached native callback; no success, writer, honesty or field premise is added. -/
theorem table_callback {A Result : Type} (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (ensureInit : StateT A ProbComp Bool) (supplied : Option Pqxdh.Bytes)
    (adversary : PublicIdentity → U64 → OracleComp PqxdhRegistrationSchedule.SurfaceSpec Result)
    (runtime afterRuntime : A) (created : PqxdhLiveServerConstruction.Created Unit)
    (answer : Result) (state : PqxdhRegistrationSchedule.State KemSK)
    (table : PqxdhRegistrationPendingTables.PendingTable)
    (supported : (some (created, answer, state, table), afterRuntime) ∈ support
      (PqxdhRegistrationTableDispatcher.experiment setup codec checks ensureInit supplied adversary runtime))
    (index : Nat) (payload : Option Pqxdh.Bytes) :
    ∃ encoded : Pqxdh.Bytes,
      build setup codec checks index payload encoded ((afterRuntime, state), table) =
        (PqxdhRegistrationTableDispatcher.handler setup codec checks created.seed ensureInit
          (PqxdhRegistrationBuildLookup.buildQuery index payload)).run ((afterRuntime, state), table) ∧
      (build setup codec checks index payload encoded ((afterRuntime, state), table)).IsTotalQueryBound 64 := by
  obtain ⟨encoded, _, same, bounded⟩ := PqxdhRegistrationIdentityProcess.table_callback setup codec checks
    ensureInit supplied adversary runtime afterRuntime created answer state table supported index payload
  exact ⟨encoded, (build_identity setup codec checks index payload encoded _).trans same,
    (build_identity setup codec checks index payload encoded _).symm ▸ bounded⟩

end BeaconcryptCore.Computational.PqxdhRegistrationPayloadProcess

/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationPayloadProcess.response_identity' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationPayloadProcess.response_identity
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationPayloadProcess.present_identity' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationPayloadProcess.present_identity
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationPayloadProcess.build_identity' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationPayloadProcess.build_identity
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationPayloadProcess.table_callback' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationPayloadProcess.table_callback
