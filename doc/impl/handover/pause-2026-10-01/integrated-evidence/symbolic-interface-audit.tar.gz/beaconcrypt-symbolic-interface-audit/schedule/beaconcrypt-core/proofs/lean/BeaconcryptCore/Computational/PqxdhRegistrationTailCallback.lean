-- SPDX-License-Identifier: 0BSD
import BeaconcryptCore.Computational.PqxdhRegistrationTailOperations

/-! The complete real tail operation program at the actual numeric-table callback. Private receipts preserve reached values and writer outcomes; they do not authorize admission or become public replies. -/
open OracleComp OracleSpec CoreModels Aeneas
open Aeneas.Std hiding namespace core alloc
open RustM beaconcrypt_core ratchet ratchet.concrete PqxdhRefinement
set_option autoImplicit false
namespace BeaconcryptCore.Computational.PqxdhRegistrationTailCallback
open PqxdhServerRegistrationPublication PqxdhRegistrationTailPrimitives
open PqxdhRegistrationResponseTail PqxdhRegistrationTailNative PqxdhRegistrationTailOperations
open PqxdhServerAuthExperiment (Setup Codec Checks tailImpl settle)
variable {ι KemSK Reader WireResponse : Type} {baseSpec : OracleSpec ι}

/-- Rejections before a candidate and the actual candidate's complete tail receipt are distinct. The supplied public encoded field remains an input, never reconstructed from a secret. -/
inductive Receipt where
  | counterRefused
  | peerOccupied (next : U64)
  | identityRefused
  | candidate (prepared : pqxdh.ServerRegistrationCandidate) (receipt : CandidateReceipt)

noncomputable def Receipt.output {Metadata PeerMetadata Consumed : Type}
    (metadata : PeerMetadata) (state : State Metadata PeerMetadata Consumed) :
    Receipt → Option Response × State Metadata PeerMetadata Consumed
  | .candidate prepared receipt => receipt.output prepared metadata state
  | _ => (none, state)

/-- The original public successor, occupied-peer and identity operations precede the complete real tail interpreter. Candidate and initializer diagnostics are retained verbatim. -/
noncomputable def response {Metadata PeerMetadata Consumed : Type}
    (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse) (checks : Checks)
    (pending : pqxdh.PendingServerRegistration) (encoded : Pqxdh.Bytes)
    (root : PqxdhSecretInputKdf.RootOutput) (data : Option Pqxdh.Bytes)
    (state : State Metadata PeerMetadata Consumed) : Logged (RustM Receipt) :=
  match PqxdhRegistrationBuildCounter.successor state.control.last_key_id with
  | none => pure (ok .counterRefused)
  | some next =>
      if (state.server.peers next).isSome then pure (ok (.peerOccupied next)) else
        match PqxdhEd25519EufCma.parseIdentity encoded with
        | none => pure (ok .identityRefused)
        | some identity => PqxdhInitialGenericBuilder.continueRust
            (PqxdhRegistrationBuildCounter.candidate state.control
              { pending with beacon_identity_public_key := PqxdhRootTableInitialization.rootArray identity }
              ⟨state.server.identity, state.identityKeyId⟩ next) fun prepared =>
                (fun receipt => Receipt.candidate prepared <$> receipt) <$>
                  simulateQ (implementation setup codec checks) (code prepared root data)

/-- The complete operation/value program restores the original public response and entire logged source state, including every refused writer and discarded candidate. -/
theorem response_erase {Metadata PeerMetadata Consumed : Type}
    (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse) (checks : Checks)
    (pending : pqxdh.PendingServerRegistration) (encoded : Pqxdh.Bytes)
    (root : PqxdhSecretInputKdf.RootOutput) (data : Option Pqxdh.Bytes)
    (metadata : PeerMetadata) (state : State Metadata PeerMetadata Consumed) :
    (fun receipt => Receipt.output metadata state <$> receipt) <$>
      response setup codec checks pending encoded root data state =
      simulateQ (tailImpl setup codec checks)
        (PqxdhRegistrationPayloadProcess.response setup.source pending encoded root data metadata state) := by
  simp only [response, PqxdhRegistrationPayloadProcess.response]
  cases next : PqxdhRegistrationBuildCounter.successor state.control.last_key_id with
  | none => rfl
  | some nextId =>
    simp only
    split_ifs
    · rfl
    · cases identity : PqxdhEd25519EufCma.parseIdentity encoded with
      | none => rfl
      | some identityKey =>
        simp only
        cases prepared : PqxdhRegistrationBuildCounter.candidate state.control
          { pending with beacon_identity_public_key := PqxdhRootTableInitialization.rootArray identityKey }
          ⟨state.server.identity, state.identityKeyId⟩ nextId <;>
          simp only [PqxdhInitialGenericBuilder.continueRust, continueRust, map_pure, simulateQ_pure]
        all_goals try rfl
        simp only [Functor.map_map, Receipt.output, code_source, ← PqxdhRegistrationResponseEncoding.candidate_encoding]
        exact candidateSource_erase setup codec checks _ root data metadata state

open PqxdhJointIdentity PqxdhJointGapDh PqxdhServerAuthNative

/-- Private provenance at a reached table callback. These are the supplied token and field from that call, not values reconstructed from a frame or final key. -/
structure CallReceipt where
  session : Nat
  token : PqxdhServerRelatedRootConsumer.Returned
  encoded : Pqxdh.Bytes
  payload : Option Pqxdh.Bytes
  receipt : RustM Receipt

/-- Execute the original present-token continuation, attaching its real tail receipt only to private analysis output. All state effects and successful-seal observations are reinstalled at their original source boundary. -/
noncomputable def present (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse)
    (checks : Checks) (session : Nat) (payload : Option Pqxdh.Bytes)
    (token : PqxdhServerRelatedRootConsumer.Returned) (encoded : Pqxdh.Bytes) (state : NativeState KemSK) :
    ProbComp ((Option Response × CallReceipt) × NativeState KemSK) :=
  (fun result =>
    let settled := settle state.2.server (Receipt.output () state.2.server <$> result.1)
    ((settled.1, ⟨session, token, encoded, payload, result.1⟩), state.1, { state.2 with
      pending := Function.update state.2.pending session none
      server := settled.2
      ctx := result.2.2
      ghost := { state.2.ghost with seals := state.2.ghost.seals ++ result.2.1.map (fun context => (session, context)) } })) <$>
    (response setup codec checks token.pending encoded token.root payload state.2.server).run
      ([], state.2.ctx)

/-- Erasure retains the actual optional reply and entire native state, including the original pending disposal and source observations on a failed outer writer. -/
theorem present_erase (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse)
    (checks : Checks) (session : Nat) (payload : Option Pqxdh.Bytes)
    (token : PqxdhServerRelatedRootConsumer.Returned) (encoded : Pqxdh.Bytes) (state : NativeState KemSK) :
    (fun result => (result.1.1, result.2)) <$> present setup codec checks session payload token encoded state =
      PqxdhRegistrationPayloadProcess.present setup codec checks session payload token encoded state := by
  unfold present PqxdhRegistrationPayloadProcess.present
  rw [← response_erase]
  simp only [StateT.run_map, Functor.map_map]

/-- The table dispatcher consumes the same actual available token before the complete tail. Missing, future and spent indices produce the original normal rejection and no invented callback receipt. -/
noncomputable def build {A : Type} (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse)
    (checks : Checks) (session : Nat) (payload : Option Pqxdh.Bytes) (encoded : Pqxdh.Bytes)
    (state : PqxdhRegistrationTableDispatcher.State KemSK A) :
    ProbComp ((Option Response × Option CallReceipt) × PqxdhRegistrationTableDispatcher.State KemSK A) :=
  let restored := PqxdhRegistrationTableDispatcher.restore state
  match PqxdhRegistrationBuildLookup.available state.2 session with
  | none => pure ((none, none), PqxdhRegistrationTableDispatcher.clear state)
  | some token =>
      let consumed := state.2.consume session
      (fun result => ((result.1.1, some result.1.2), PqxdhRegistrationTableDispatcher.clear
        ((restored.1, { restored.2 with shared := result.2 }), consumed))) <$>
        present setup codec checks session payload token encoded (PqxdhRegistrationBuildLookup.dispose restored.2.shared session)

/-- Removing the private response receipt restores the entire actual previous table callback, for every supplied state and every optional result. -/
theorem build_erase {A : Type} (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse)
    (checks : Checks) (session : Nat) (payload : Option Pqxdh.Bytes) (encoded : Pqxdh.Bytes)
    (state : PqxdhRegistrationTableDispatcher.State KemSK A) :
    (fun result => (result.1.1, result.2)) <$> build setup codec checks session payload encoded state =
      PqxdhRegistrationPayloadProcess.build setup codec checks session payload encoded state := by
  unfold build PqxdhRegistrationPayloadProcess.build
  cases available : PqxdhRegistrationBuildLookup.available state.2 session <;> dsimp only
  · rfl
  · rw [← present_erase]
    simp only [Functor.map_map]

/-- Actual supplied/generated construction and the entire preceding adaptive table schedule supply the field witness. The complete observed operation has the original source reply/state projection and full uniform64 bill; local observation and runtime costs are not cryptographic-query costs. -/
theorem table_callback {A Result : Type} (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse)
    (checks : Checks) (ensureInit : StateT A ProbComp Bool) (supplied : Option Pqxdh.Bytes)
    (adversary : PublicIdentity → U64 → OracleComp PqxdhRegistrationSchedule.SurfaceSpec Result)
    (runtime afterRuntime : A) (created : PqxdhLiveServerConstruction.Created Unit)
    (answer : Result) (state : PqxdhRegistrationSchedule.State KemSK)
    (table : PqxdhRegistrationPendingTables.PendingTable)
    (supported : (some (created, answer, state, table), afterRuntime) ∈ support
      (PqxdhRegistrationTableDispatcher.experiment setup codec checks ensureInit supplied adversary runtime))
    (index : Nat) (payload : Option Pqxdh.Bytes) :
    ∃ encoded : Pqxdh.Bytes,
      (fun result => (result.1.1, result.2)) <$> build setup codec checks index payload encoded ((afterRuntime, state), table) =
        (PqxdhRegistrationTableDispatcher.handler setup codec checks created.seed ensureInit
          (PqxdhRegistrationBuildLookup.buildQuery index payload)).run ((afterRuntime, state), table) ∧
      (build setup codec checks index payload encoded ((afterRuntime, state), table)).IsTotalQueryBound 64 := by
  obtain ⟨encoded, same, bounded⟩ := PqxdhRegistrationPayloadProcess.table_callback setup codec checks
    ensureInit supplied adversary runtime afterRuntime created answer state table supported index payload
  refine ⟨encoded, (build_erase setup codec checks index payload encoded _).trans same, ?_⟩
  rw [← build_erase setup codec checks index payload encoded _] at bounded
  simpa only [IsTotalQueryBound, isQueryBound_map_iff] using bounded

end BeaconcryptCore.Computational.PqxdhRegistrationTailCallback

/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailCallback.response_erase' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailCallback.response_erase
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailCallback.present_erase' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailCallback.present_erase
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailCallback.build_erase' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailCallback.build_erase
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailCallback.table_callback' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailCallback.table_callback
