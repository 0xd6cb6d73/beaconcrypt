-- SPDX-License-Identifier: 0BSD
import BeaconcryptCore.Computational.PqxdhRegistrationTailCallback

/-! The maintained complete response body on its real source-value image. The renderer is checked against the literal process text. Cryptographic expressions retain the real endpoint interpretation, not free-constructor laws or arbitrary applied-pi semantics. -/
open OracleComp OracleSpec CoreModels Aeneas
open Aeneas.Std hiding namespace core alloc
open RustM beaconcrypt_core ratchet ratchet.concrete PqxdhRefinement
set_option autoImplicit false
namespace BeaconcryptCore.Computational.PqxdhRegistrationTailProcess
open PqxdhServerRegistrationPublication PqxdhRegistrationTailPrimitives PqxdhRegistrationResponseTail
open PqxdhRegistrationTailOperations

/-- The complete maintained body, including all seven failure stages and its publication branch. Its real operation program is `code`; equality to the native source is proved in `code_source`. This fixed-body binding is not a parser or semantics for arbitrary applied-pi terms. -/
def sourceText : String := r#"let RegistrationResponseTail(owner: bitstring, token: bitstring, reply: channel,
  mutex: channel, counter: channel, before: nat, next: nat,
  server_identity: bitstring, server_id: key_id, beacon_identity: bitstring,
  ephemeral: bitstring, ciphertext: bitstring, root: bitstring,
  data: bitstring, failure_stage: nat) =
  if failure_stage <> 1 then (
    if failure_stage <> 2 then (
      let associated_data = beaconcrypt_core__pqxdh__build_associated_data(server_identity, beacon_identity) in
      let send_chain = server_to_beacon_chain(root) in
      let receive_chain = beacon_to_server_chain(root) in
      event RegistrationResponsePrepared(owner, token, next, root, send_chain, receive_chain);
      let plaintext = registration_response_plaintext(data) in (
        if failure_stage <> 3 then (
          if failure_stage <> 4 then (
            let assigned = registration_response_identifier(next) in
            let binding = beaconcrypt_core__pqxdh__RegistrationKeyIdBinding(key_id_encoding(assigned)) in
            let authenticated = registration_payload(binding, plaintext) in
            let material = ratchet_material(send_chain) in
            if failure_stage <> 5 then (
              let frame = seal_frame(material, associated_data, first_sequence(), server_id, authenticated) in
              if failure_stage <> 6 then (
                event RegistrationResponseInnerWritten(owner, token, assigned, authenticated, frame);
                let response = kex_response(server_identity, ephemeral, ciphertext, frame, assigned) in
                if failure_stage <> 7 then (
                  let advanced = ratchet_next(send_chain) in
                  insert registration_response_peers(owner, assigned, beacon_identity, associated_data, advanced, receive_chain);
                  event RegistrationResponseInstalled(owner, token, assigned, associated_data, advanced, receive_chain);
                  event RegistrationResponsePublished(owner, token, before, next, assigned, authenticated, frame, response);
                  RegistrationResponseReturn(owner, token, reply, mutex, counter,
                    before, next, true, registration_response_success(response))
                ) else RegistrationResponseFailure(owner, token, reply, mutex, counter, before)
              ) else RegistrationResponseFailure(owner, token, reply, mutex, counter, before)
            ) else RegistrationResponseFailure(owner, token, reply, mutex, counter, before)
          ) else RegistrationResponseFailure(owner, token, reply, mutex, counter, before)
        ) else RegistrationResponseFailure(owner, token, reply, mutex, counter, before)
      ) else RegistrationResponseFailure(owner, token, reply, mutex, counter, before)
    ) else RegistrationResponseFailure(owner, token, reply, mutex, counter, before)
  ) else RegistrationResponseFailure(owner, token, reply, mutex, counter, before).
"#

/-- The exact default expression evaluates to the same source [255] as the ordinary `Option.none` branch. Equal supplied bytes may alias this value. -/
def plaintextText : String := r#"letfun registration_response_plaintext(data: bitstring) =
  if data = registration_response_default_payload() then
    registration_response_nonempty(registration_response_witness())
  else let registration_response_nonempty(bytes: bitstring) = data in data.
"#

/-- Completion releases the counter and mutex independently of delivery. Both maintained branches are bound here without changing their existing process semantics. -/
def returnText : String := r#"let RegistrationResponseReturn(owner: bitstring, token: bitstring, reply: channel,
  mutex: channel, counter: channel, before: nat, after: nat,
  success: bool, result: bitstring) =
  event RegistrationResponseCompleted(owner, token, before, after, success);
  (out(counter, after) | out(mutex, registration_set_mutex()) | out(reply, result)).

let RegistrationResponseFailure(owner: bitstring, token: bitstring, reply: channel,
  mutex: channel, counter: channel, before: nat) =
  event RegistrationResponseFailed(owner, token);
  RegistrationResponseReturn(owner, token, reply, mutex, counter, before, before,
    false, registration_set_failure()).
"#

/-- A reached response writer has exactly the fields formed from the same returned inner frame. An absent inner frame prevents that writer from running. -/
def Shape (prepared : pqxdh.ServerRegistrationCandidate) (receipt : AfterReceipt) : Prop :=
  match receipt.sent.output.2 with
  | none => receipt.written = none
  | some encrypted => ∃ written, receipt.written = some (responseFields prepared encrypted, written)

/-- Every possible reply path of the full post-initialization operation body establishes the inner/outer writer relation, before choosing a particular real interpreter. -/
theorem after_shape (prepared : pqxdh.ServerRegistrationCandidate) (authenticated : Pqxdh.Bytes)
    (kernel : ConcreteRatchetKernel) (receipt : AfterReceipt)
    (supported : receipt ∈ support (afterCode prepared authenticated kernel)) : Shape prepared receipt := by
  simp only [afterCode, mem_support_bind_iff] at supported
  obtain ⟨sent, _, erased, _, supported⟩ := supported
  cases sealed : sent.output.2 <;> simp only [sealed, mem_support_pure_iff, mem_support_bind_iff] at supported
  · subst receipt
    simp only [Shape, sealed]
  · obtain ⟨written, _, rfl⟩ := supported
    simp only [Shape, sealed]
    exact ⟨written, rfl⟩

/-- Candidate refusals and native diagnostics retain their own meanings. Only a reached first-send continuation carries a writer relation. -/
def CandidateShape (prepared : pqxdh.ServerRegistrationCandidate) : RustM CandidateReceipt → Prop
  | .ok (.attempted _ _ receipt) => Shape prepared receipt
  | _ => True

/-- Every all-reply path of the complete response body supplies its writer-value relation. The actual sampler and earlier source state need no extra writer or success premise. -/
theorem code_shape (prepared : pqxdh.ServerRegistrationCandidate) (root : PqxdhSecretInputKdf.RootOutput)
    (data : Option Pqxdh.Bytes) (result : RustM CandidateReceipt)
    (supported : result ∈ support (code prepared root data)) : CandidateShape prepared result := by
  simp only [code, mem_support_bind_iff] at supported
  obtain ⟨valid, _, supported⟩ := supported
  cases valid <;> simp only [Bool.not_false, Bool.not_true, Bool.false_eq_true, ite_true, ite_false, mem_support_pure_iff, mem_support_bind_iff] at supported
  · subst result
    trivial
  · obtain ⟨reserved, _, supported⟩ := supported
    cases reserved <;> simp only [Bool.not_false, Bool.not_true, Bool.false_eq_true, ite_true, ite_false, mem_support_pure_iff, mem_support_bind_iff] at supported
    · subst result
      trivial
    · obtain ⟨initialized, _, supported⟩ := supported
      cases initialized <;> simp only [continueRust, mem_support_pure_iff, mem_support_bind_iff] at supported
      all_goals first | (subst result; trivial) | skip
      obtain ⟨plaintext, _, supported⟩ := supported
      split_ifs at supported <;> simp only [mem_support_pure_iff, mem_support_bind_iff] at supported
      all_goals first | (subst result; trivial) | skip
      obtain ⟨allocated, _, supported⟩ := supported
      cases allocated <;> simp only [Bool.not_false, Bool.not_true, Bool.false_eq_true, ite_true, ite_false, mem_support_pure_iff, mem_support_bind_iff] at supported
      · subst result
        trivial
      · obtain ⟨authenticated, _, supported⟩ := supported
        rw [support_map] at supported
        obtain ⟨receipt, reached, rfl⟩ := supported
        exact after_shape prepared authenticated _ receipt reached

/-- The numbered refusal branches of the maintained body. The stage describes reached source work; it does not remove any of that work from the full interpreter. -/
inductive FailureStage where
  | identity | reserve | length | allocation | sealing | frame | response
  deriving DecidableEq

def FailureStage.number : FailureStage → Nat
  | .identity => 1
  | .reserve => 2
  | .length => 3
  | .allocation => 4
  | .sealing => 5
  | .frame => 6
  | .response => 7

/-- Source diagnostics are kept outside ordinary symbolic refusal stages. Missing-writer is an inconsistent annotation, excluded by the generated writer relation below. -/
inductive Control where
  | failed (stage : FailureStage)
  | published
  | exhausted
  | missingWriter
  deriving DecidableEq

/-- Read the actual two optional writer outcomes and detailed seal diagnostics; no publication is inferred from a cryptographic seal. -/
def afterControl (receipt : AfterReceipt) : Control :=
  match receipt.written with
  | some (_, some _) => .published
  | some (_, none) => .failed .response
  | none => match receipt.sent with
    | .exhausted _ => .exhausted
    | .attempted _ _ sealing => match sealing with
      | .frame _ _ _ none => .failed .frame
      | .frame _ _ _ (some _) => .missingWriter
      | _ => .failed .sealing

/-- Normal candidate refusals use the source's exact branch numbers. The explicit native RustM wrapper still retains fail/div results. -/
def control : CandidateReceipt → Control
  | .identityRefused => .failed .identity
  | .peerRefused => .failed .reserve
  | .emptyPlaintext _ => .failed .length
  | .oversizedPlaintext _ _ => .failed .length
  | .allocationRefused _ _ => .failed .allocation
  | .attempted _ _ receipt => afterControl receipt

/-- Only a returned outer response is publication; the entire installed kernel and counter are the original source output. This equality includes every failed seal or writer. -/
theorem control_published {Metadata PeerMetadata Consumed : Type}
    (prepared : pqxdh.ServerRegistrationCandidate) (metadata : PeerMetadata)
    (state : State Metadata PeerMetadata Consumed) (receipt : CandidateReceipt) :
    control receipt = .published ↔ (receipt.output prepared metadata state).1.isSome = true := by
  cases receipt <;> simp only [control, CandidateReceipt.output, Option.isSome_none, Bool.false_eq_true, reduceCtorEq]
  rename_i kernel plaintext receipt
  rcases receipt with ⟨sent, _ | ⟨fields, _ | bytes⟩⟩ <;> simp only [afterControl, AfterReceipt.output, Option.isSome_none, Option.isSome_some, reduceCtorEq, Bool.false_eq_true]
  cases sent with
  | exhausted kernel => simp
  | attempted pending response sealing =>
    cases sealing <;> simp
    split <;> simp

/-- The real interpreter supplies the writer relation for the complete evaluated body, at arbitrary original log/cache state. This is support transport of the whole program, not an assumed successful-write contract. -/
theorem interpreted_shape {ι KemSK Reader WireResponse : Type} {baseSpec : OracleSpec ι}
    (setup : PqxdhServerAuthExperiment.Setup baseSpec KemSK)
    (codec : PqxdhServerAuthExperiment.Codec Reader WireResponse) (checks : PqxdhServerAuthExperiment.Checks)
    (prepared : pqxdh.ServerRegistrationCandidate) (root : PqxdhSecretInputKdf.RootOutput)
    (data : Option Pqxdh.Bytes) (before : RawCtxSharedPrimitive.SharedState (List RawCtxSourceSend.SealContext))
    (result : RustM CandidateReceipt × RawCtxSharedPrimitive.SharedState (List RawCtxSourceSend.SealContext))
    (supported : result ∈ support ((simulateQ (implementation setup codec checks) (code prepared root data)).run before)) :
    CandidateShape prepared result.1 := by
  apply code_shape prepared root data result.1
  apply support_simulateQ_run'_subset (implementation setup codec checks) _ before
  rw [StateT.run'_eq, support_map]
  exact ⟨result, supported, rfl⟩

/-- A successful response is related to the exact inner frame and original published kernel from that same execution. The relation uses the actual writer arguments; it never inverts serialized bytes or assumes a total codec. -/
theorem writer_values {Metadata PeerMetadata Consumed : Type}
    (prepared : pqxdh.ServerRegistrationCandidate) (authenticated : Pqxdh.Bytes)
    (kernel : ConcreteRatchetKernel) (receipt : AfterReceipt)
    (supported : receipt ∈ support (afterCode prepared authenticated kernel))
    (metadata : PeerMetadata) (state : State Metadata PeerMetadata Consumed)
    (fields : ResponseFields) (bytes : Pqxdh.Bytes)
    (written : receipt.written = some (fields, some bytes)) :
    ∃ encrypted, receipt.sent.output.2 = some encrypted ∧
      fields = responseFields prepared encrypted ∧
      receipt.output prepared metadata state =
        (some ⟨bytes, prepared.key_id⟩, publish state prepared receipt.sent.output.1 metadata) := by
  have shape := after_shape prepared authenticated kernel receipt supported
  cases framed : receipt.sent.output.2 with
  | none => simp only [Shape, framed, written, reduceCtorEq] at shape
  | some encrypted =>
    simp only [Shape, framed] at shape
    obtain ⟨outer, actual⟩ := shape
    rw [written] at actual
    refine ⟨encrypted, rfl, (Prod.mk.inj (Option.some.inj actual)).1, ?_⟩
    simp only [AfterReceipt.output, written]

/-- The full body cannot claim that the outer writer was skipped after obtaining an inner frame. Its generated relation excludes that inconsistent annotation without a codec premise. -/
theorem writer_present (prepared : pqxdh.ServerRegistrationCandidate) (receipt : AfterReceipt)
    (shape : Shape prepared receipt) : afterControl receipt ≠ .missingWriter := by
  rcases receipt with ⟨sent, _ | ⟨fields, _ | bytes⟩⟩ <;> simp only [afterControl, ne_eq, reduceCtorEq, not_false_eq_true]
  cases sent with
  | exhausted kernel => simp
  | attempted pending response sealing =>
    cases sealing <;> simp
    rename_i body tag commitment written
    cases written <;> simp_all [Shape, SendReceipt.output, SealReceipt.output]

end BeaconcryptCore.Computational.PqxdhRegistrationTailProcess

/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailProcess.after_shape' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailProcess.after_shape
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailProcess.code_shape' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailProcess.code_shape
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailProcess.control_published' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailProcess.control_published
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailProcess.interpreted_shape' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailProcess.interpreted_shape
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailProcess.writer_values' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailProcess.writer_values
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailProcess.writer_present' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailProcess.writer_present
