"""Focused diagnostic runs of the existing burst, with optional perf/PG wait sampling."""
import argparse, json, os, signal, subprocess, threading, time
from pathlib import Path
import psycopg

ROOT = Path(__file__).resolve().parent
PG = Path('/nix/store/2bq8r5zag09ngvxr3jnfxhww1x904psn-postgresql-16.15/bin')
PERF = '/nix/store/c68d5zbr1ng5wkhwkms12y0j8899wc7i-perf-linux-7.2.2/bin/perf'
WORK = '/home/user/worktrees/beaconcrypt-row-burst-profile'
DSN = 'host=127.0.0.1 port=55459 user=bcbench dbname=postgres sslmode=disable application_name=bc-burst-profile'

def observe(stop, path, database):
    with path.open('x') as log:
        if database:
            connection = psycopg.connect(DSN.replace('bc-burst-profile', 'bc-profile-observer'), autocommit=True)
            connection.execute("SET stats_fetch_consistency='none'")
        next_host = 0
        while not stop.is_set():
            begin = time.monotonic_ns()
            record = {'begin_ns': begin}
            if database:
                record['backends'] = connection.execute("SELECT pid,state,wait_event_type,wait_event FROM pg_stat_activity WHERE application_name='bc-burst-profile' ORDER BY pid").fetchall()
            if begin >= next_host:
                record['proc_stat'] = Path('/proc/stat').read_text().splitlines()[0]
                record['loadavg'] = Path('/proc/loadavg').read_text().strip()
                next_host = begin + 250_000_000
            record['end_ns'] = time.monotonic_ns()
            log.write(json.dumps(record) + '\n')
            stop.wait(0.002 if database else 0.25)
        if database:
            connection.close()

def run(label, trials, peers, profile, history=False):
    output = ROOT / label
    output.mkdir()
    args = [str(ROOT/('persistence_bench-history' if history else 'persistence_bench')), '--run', '--mode', 'concurrent', '--backend', 'postgres', '--peers', str(peers), '--active-peers', '32', '--workers', '8', '--trials', str(trials), '--burst-chunks', '512', '--period-ms', '1000,100,10,5', '--arrival-ms', '2000', '--output', str(output/'report.json'), '--database-directory', str(output)]
    env = os.environ.copy()
    env['BEACONCRYPT_BENCH_POSTGRES'] = DSN
    env['BC_PROFILE_HISTORY'] = '1' if history else '0'
    if profile:
        control, ack = output/'control.fifo', output/'ack.fifo'
        os.mkfifo(control, 0o600)
        os.mkfifo(ack, 0o600)
        args = ['sudo', '-n', PERF, 'record', '-a', '-e', 'cpu-clock:u', '-F', '999', '--call-graph', 'dwarf,8192', '-k', 'mono', '-e', 'syscalls:sys_enter_fdatasync', '-e', 'syscalls:sys_exit_fdatasync', '-e', 'syscalls:sys_enter_fsync', '-e', 'syscalls:sys_exit_fsync', '-D', '-1', '--control', f'fifo:{control},{ack}', '-o', str(output/'perf.data'), '--', 'sudo', '-n', '-u', 'user', 'env', f'BEACONCRYPT_BENCH_POSTGRES={DSN}', f'BC_PROFILE_HISTORY={int(history)}', f'BC_PROFILE_CONTROL={control}', f'BC_PROFILE_ACK={ack}', *args]
    (output/'command.json').write_text(json.dumps({'argv':args,'dsn':DSN,'profile':profile}, indent=2)+'\n')
    stop = threading.Event()
    observer = threading.Thread(target=observe, args=(stop, output/'observer.jsonl', profile))
    observer.start()
    started = time.monotonic_ns()
    try:
        with (output/'run.log').open('x') as log:
            process = subprocess.run(args, cwd=WORK, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=1200)
        if process.returncode:
            raise RuntimeError(f'{label}: command exited {process.returncode}; inspect run.log')
    finally:
        stop.set()
        observer.join()
    report = json.loads((output/'report.json').read_text())
    assert report['status']=='complete'
    assert len(report['results'])==2*trials*(13 if history else 1)
    for r in report['results']:
        assert r['arm'] in ('row','cached_row')
        if not history: assert r['scenario']=='burst_512'
        assert r['status']=='complete' and r['outputs_verified'] and not r['failures']
        assert r['offered']==r['messages']
        if r['scenario']=='burst_512': assert r['messages']==512
    (output/'receipt.json').write_text(json.dumps({'started_ns':started,'ended_ns':time.monotonic_ns(),'trials':trials,'arms':2,'callbacks':sum(r['messages'] for r in report['results']),'burst_callbacks':trials*1024,'history':history,'status':'complete'},indent=2)+'\n')
    if profile:
        subprocess.run(['sudo','-n','chown',f'{os.getuid()}:{os.getgid()}',str(output/'perf.data')],check=True)
    print(f'{label}: {len(report["results"])} complete arms, outputs verified', flush=True)

parser=argparse.ArgumentParser()
parser.add_argument('mode', choices=['smoke','collect','history'])
args=parser.parse_args()
cluster=ROOT/'pgdata'
with (ROOT/f'{args.mode}-postgres-control-v2.log').open('x') as log:
    subprocess.run([str(PG/'pg_ctl'),'-D',str(cluster),'-l',str(ROOT/'postgres.log'),'start','-w','-t','30'],stdout=log,stderr=subprocess.STDOUT,check=True)
    try:
        if args.mode=='smoke':
            run('smoke-v2',1,1,True)
        else:
            # Full resource lease is held by the caller; allow startup/build activity to settle.
            with (ROOT/f'{args.mode}-settle.jsonl').open('x') as settle:
                for _ in range(60):
                    settle.write(json.dumps({'monotonic_ns':time.monotonic_ns(),'proc_stat':Path('/proc/stat').read_text().splitlines()[0]})+'\n')
                    time.sleep(1)
            if args.mode=='history':
                run('history',2,1000,True,history=True)
            else:
                run('baseline',6,1000,False)
                run('sampled',4,1000,True)
    finally:
        subprocess.run([str(PG/'pg_ctl'),'-D',str(cluster),'stop','-m','fast','-w','-t','30'],stdout=log,stderr=subprocess.STDOUT,check=True)
