"""Read audit evidence; never execute a test or modify the frozen source."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "results/mutants.out"
catalog = json.loads((ROOT / "catalog.json").read_text())
executed = json.loads((OUTPUT / "mutants.json").read_text())
assert catalog == executed
data = json.loads((OUTPUT / "outcomes.json").read_text())
names = {mutant["name"] for mutant in catalog}
seen = set()
groups = Counter()
unviable = []
missed = []
timeouts = []
unexpected = []
for outcome in data["outcomes"]:
    for phase in outcome["phase_results"]:
        argv = phase["argv"]
        assert argv[1:3] == ["nextest", "run"], argv
        assert "--example=persistence_bench" in argv, argv
        assert "--run-ignored=all" in argv and "--test-threads=1" in argv
        assert "--retries=0" in argv
    if outcome["scenario"] == "Baseline":
        assert outcome["summary"] == "Success"
        assert re.search(r"59 tests run: 59 passed(?: \(\d+ slow\))?, 1 skipped", (OUTPUT / outcome["log_path"]).read_text())
        continue
    mutant = outcome["scenario"]["Mutant"]
    name = mutant["name"]
    assert name in names and name not in seen, name
    seen.add(name)
    summary = outcome["summary"]
    groups[(mutant["file"], summary)] += 1
    phases = outcome["phase_results"]
    if summary == "CaughtMutant":
        if phases[-1]["phase"] != "Test" or phases[-1]["process_status"] != {"Failure": 100}:
            unexpected.append({"name": name, "summary": summary, "phases": phases})
    elif summary == "MissedMutant":
        log = (OUTPUT / outcome["log_path"]).read_text()
        assert re.search(r"59 tests run: 59 passed(?: \(\d+ slow\))?, 1 skipped", log)
        missed.append({"name": name, "log": outcome["log_path"], "diff": outcome["diff_path"]})
    elif summary == "Unviable":
        log = (OUTPUT / outcome["log_path"]).read_text()
        errors = [line for line in log.splitlines() if line.startswith("error[") or line.startswith("error:")]
        unviable.append({"name": name, "errors": errors, "log": outcome["log_path"]})
        if phases[-1]["phase"] != "Build" or not errors:
            unexpected.append({"name": name, "summary": summary, "phases": phases})
    else:
        timeouts.append({"name": name, "summary": summary, "log": outcome["log_path"]})

review = {
    "catalog_count": len(catalog), "completed": len(seen),
    "complete_catalog": seen == names, "executed_catalog_matches": True,
    "counts": {key: data[key] for key in ["missed", "caught", "timeout", "unviable"]},
    "by_file_and_outcome": [
        {"file": file, "outcome": outcome, "count": count}
        for (file, outcome), count in sorted(groups.items())
    ],
    "missed": missed, "unviable": unviable, "timeouts_or_unknown": timeouts,
    "unexpected_phase_or_status": unexpected,
    "outcomes_sha256": hashlib.sha256((OUTPUT / "outcomes.json").read_bytes()).hexdigest(),
    "catalog_sha256": hashlib.sha256((ROOT / "catalog.json").read_bytes()).hexdigest(),
}
(ROOT / "outcome-review.json").write_text(json.dumps(review, indent=2) + "\n")
print(json.dumps({key: review[key] for key in ["catalog_count", "completed", "complete_catalog", "counts"]}))
if "--summary" not in sys.argv:
    for issue in [*missed, *timeouts, *unexpected]:
        print(json.dumps(issue))
if "--unviable" in sys.argv:
    for issue in unviable:
        print("UNVIABLE", json.dumps(issue))
