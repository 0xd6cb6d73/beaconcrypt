-- SPDX-License-Identifier: 0BSD
import BeaconcryptCore.Computational.PqxdhRegistrationTailNative

/-! Internal operation/value interpretation for the complete maintained RegistrationResponseTail. These operations are not a new public oracle or protocol API. Cryptographic and codec operations execute the original real endpoints; their stronger symbolic equations are not inferred here. -/
open OracleComp OracleSpec CoreModels Aeneas
open Aeneas.Std hiding namespace core alloc
open RustM beaconcrypt_core ratchet ratchet.concrete PqxdhRefinement
set_option autoImplicit false
namespace BeaconcryptCore.Computational.PqxdhRegistrationTailOperations
open PqxdhServerRegistrationPublication PqxdhRegistrationTailPrimitives
open PqxdhRegistrationResponseTail PqxdhRegistrationTailNative
open PqxdhServerAuthExperiment (Setup Codec Checks tailImpl)
variable {ι KemSK Reader WireResponse : Type} {baseSpec : OracleSpec ι}

/-- The finite private operation boundary of this one response body. Pure projections are explicit operations in this interpretation, not extra cryptographic oracle queries. -/
inductive Operation where
  | identity (identity : Std.Array U8 32#usize)
  | reservePeer
  | initialize (prepared : pqxdh.ServerRegistrationCandidate) (root : PqxdhSecretInputKdf.RootOutput)
  | plaintext (data : Option Pqxdh.Bytes)
  | reservePlaintext (length : Nat)
  | payload (identifier : U64) (plaintext : Pqxdh.Bytes)
  | firstSend (kernel : ConcreteRatchetKernel) (context : RawCtxSourceSend.SealContext)
  | erase (authenticated : Pqxdh.Bytes)
  | write (fields : ResponseFields)

abbrev Spec : OracleSpec Operation
  | .identity _ => Bool
  | .reservePeer => Bool
  | .initialize _ _ => RustM ConcreteRatchetKernel
  | .plaintext _ => Pqxdh.Bytes
  | .reservePlaintext _ => Bool
  | .payload _ _ => Pqxdh.Bytes
  | .firstSend _ _ => SendReceipt
  | .erase _ => Unit
  | .write _ => Option Pqxdh.Bytes

/-- The original default is one byte 255. A supplied equal byte string may alias it; no free-constructor disjointness follows from this interpretation. -/
def plaintextValue (data : Option Pqxdh.Bytes) : Pqxdh.Bytes := data.getD registrationWitness

/-- Every interpreted operation retains its original optional reply and complete native/cache state. First-send observation includes the actual successful-seal log. -/
noncomputable def implementation (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse)
    (checks : Checks) : QueryImpl Spec Logged
  | .identity identity => tailImpl setup codec checks (.inr (.checkIdentity identity))
  | .reservePeer => tailImpl setup codec checks (.inr .reservePeer)
  | .initialize prepared root => pure (BeaconcryptCore.Refinement.ServerTransactionRefinement.initializeCandidate prepared
      (PqxdhRootTableInitialization.rootArray root)
      (PqxdhRootTableInitialization.initialResponse setup.source.crypto))
  | .plaintext data => pure (plaintextValue data)
  | .reservePlaintext length => tailImpl setup codec checks (.inr (.reservePlaintext length))
  | .payload identifier plaintext => pure (PqxdhRegistrationResponseEncoding.payloadBytes identifier plaintext)
  | .firstSend kernel context => sent setup codec checks kernel context
  | .erase authenticated => tailImpl setup codec checks (.inr (.erase authenticated))
  | .write fields => tailImpl setup codec checks (.inr (.write fields))

/-- Material/sealing, mandatory erasure and the outer writer are ordered as in the full maintained tail. A returned inner frame is required before writing the response. -/
noncomputable def afterCode (prepared : pqxdh.ServerRegistrationCandidate) (authenticated : Pqxdh.Bytes)
    (kernel : ConcreteRatchetKernel) : OracleComp Spec AfterReceipt := do
  let receipt ← Spec.query (.firstSend kernel (firstContext prepared authenticated))
  let _ ← Spec.query (.erase authenticated)
  match receipt.output.2 with
  | none => pure ⟨receipt, none⟩
  | some encrypted => do
      let fields := responseFields prepared encrypted
      let written ← Spec.query (.write fields)
      pure ⟨receipt, some (fields, written)⟩

/-- The full body uses source values and source refusal decisions. Initialization diagnostics remain distinct from ordinary rejection. -/
noncomputable def code (prepared : pqxdh.ServerRegistrationCandidate) (root : PqxdhSecretInputKdf.RootOutput)
    (data : Option Pqxdh.Bytes) : OracleComp Spec (RustM CandidateReceipt) := do
  let valid ← Spec.query (.identity prepared.beacon_identity_public_key)
  if !valid then pure (ok .identityRefused) else do
    let reserved ← Spec.query .reservePeer
    if !reserved then pure (ok .peerRefused) else do
      let initialized ← Spec.query (.initialize prepared root)
      continueRust initialized fun kernel => do
        let plaintext ← Spec.query (.plaintext data)
        if plaintext.isEmpty then pure (ok (.emptyPlaintext kernel))
        else if 8 + plaintext.length ≤ Usize.max then do
          let allocated ← Spec.query (.reservePlaintext (8 + plaintext.length))
          if !allocated then pure (ok (.allocationRefused kernel plaintext)) else do
            let authenticated ← Spec.query (.payload prepared.key_id plaintext)
            (fun receipt => ok (.attempted kernel plaintext receipt)) <$> afterCode prepared authenticated kernel
        else pure (ok (.oversizedPlaintext kernel plaintext))

/-- Interpreting all post-initialization operations executes the actual complete logged source continuation. -/
theorem afterCode_source (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse)
    (checks : Checks) (prepared : pqxdh.ServerRegistrationCandidate) (authenticated : Pqxdh.Bytes)
    (kernel : ConcreteRatchetKernel) :
    simulateQ (implementation setup codec checks) (afterCode prepared authenticated kernel) =
      afterSource setup codec checks prepared authenticated kernel := by
  simp only [afterCode, afterSource, simulateQ_bind, simulateQ_spec_query, implementation]
  refine bind_congr (fun receipt => bind_congr (fun erased => ?_))
  cases receipt.output.2 <;> simp only [simulateQ_pure, simulateQ_bind, simulateQ_spec_query, implementation]
  rfl

/-- Interpreting the complete body's operation/value program preserves the actual source candidate execution and its private receipt, not just its public success bit. -/
theorem code_source (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse)
    (checks : Checks) (prepared : pqxdh.ServerRegistrationCandidate)
    (root : PqxdhSecretInputKdf.RootOutput) (data : Option Pqxdh.Bytes) :
    simulateQ (implementation setup codec checks) (code prepared root data) =
      candidateSource setup codec checks prepared root data := by
  simp only [code, candidateSource, simulateQ_bind, simulateQ_spec_query, implementation]
  refine bind_congr (fun valid => ?_)
  cases valid <;> simp only [Bool.not_false, Bool.not_true, Bool.false_eq_true, ite_false, ite_true, simulateQ_pure, simulateQ_bind, simulateQ_spec_query, implementation]
  refine bind_congr (fun reserved => ?_)
  cases reserved <;> simp only [Bool.not_false, Bool.not_true, Bool.false_eq_true, ite_false, ite_true, simulateQ_pure, simulateQ_bind, simulateQ_spec_query, implementation, pure_bind]
  cases initialized : BeaconcryptCore.Refinement.ServerTransactionRefinement.initializeCandidate prepared
    (PqxdhRootTableInitialization.rootArray root)
    (PqxdhRootTableInitialization.initialResponse setup.source.crypto) <;>
    simp only [continueRust, PqxdhInitialGenericBuilder.continueRust, simulateQ_pure, simulateQ_bind, simulateQ_spec_query, implementation, pure_bind, plaintextValue]
  split_ifs <;> simp only [simulateQ_pure, simulateQ_bind, simulateQ_spec_query, implementation]
  refine bind_congr (fun allocated => ?_)
  cases allocated <;> simp only [Bool.not_false, Bool.not_true, Bool.false_eq_true, ite_false, ite_true, simulateQ_pure, simulateQ_bind, simulateQ_spec_query, implementation, pure_bind, simulateQ_map, afterCode_source]

end BeaconcryptCore.Computational.PqxdhRegistrationTailOperations

/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailOperations.afterCode_source' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailOperations.afterCode_source
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailOperations.code_source' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailOperations.code_source
