-- SPDX-License-Identifier: 0BSD
import BeaconcryptCore.Computational.PqxdhRegistrationPayloadProcess

/-! Private actual-operation receipts for the complete response-tail interpretation. Real primitive requests and replies are retained; no free symbolic sealing constructor is substituted. -/
open OracleComp OracleSpec CoreModels Aeneas
open Aeneas.Std hiding namespace core alloc
open RustM beaconcrypt_core ratchet ratchet.concrete PqxdhRefinement
set_option autoImplicit false
namespace BeaconcryptCore.Computational.PqxdhRegistrationTailPrimitives
open RawCtxSourceSeal

/-- Distinct reached native failures and actual writer values. The source input remains the enclosing fixed argument, and these observations are private. -/
inductive SealReceipt where
  | aeadFailure
  | associatedDataFailure (body tag : Pqxdh.Bytes)
  | tagFailure (body tag : Pqxdh.Bytes)
  | hashFailure (body tag : Pqxdh.Bytes)
  | frame (body tag commitment : Pqxdh.Bytes) (written : Option Pqxdh.Bytes)

def SealReceipt.output : SealReceipt → Option Pqxdh.Bytes
  | .frame _ _ _ written => written
  | _ => none

/-- The actual native AEAD, width checks, commitment hash and frame writer execute once and in their original order. The private result distinguishes a produced record from returned frame bytes. -/
def sealing (input : RawCtxSourceSend.SealInput) : OracleComp SealSpec SealReceipt := do
  let sealed ← SealSpec.query (.inl (aeadInput input))
  match sealed with
  | none => pure .aeadFailure
  | some (body, tag) =>
      if input.context.associatedData.length = 153 then
        if tag.length = 16 then do
          let digest ← SealSpec.query (.inr (.inl (hashInput input tag)))
          match digest with
          | none => pure (.hashFailure body tag)
          | some commitment => do
              let written ← SealSpec.query (.inr (.inr (frame input body tag commitment)))
              pure (.frame body tag commitment written)
        else pure (.tagFailure body tag)
      else pure (.associatedDataFailure body tag)

/-- Erasing only the private receipt recovers the exact native sealing program, including every optional failure and all callback effects. -/
theorem seal_erase (input : RawCtxSourceSend.SealInput) :
    SealReceipt.output <$> sealing input = sealInput input := by
  simp only [sealing, sealInput, map_bind]
  refine bind_congr (fun sealed => ?_)
  rcases sealed with _ | ⟨body, tag⟩ <;> simp only [map_pure, SealReceipt.output]
  split_ifs <;> simp only [map_pure, SealReceipt.output, map_bind]
  refine bind_congr (fun digest => ?_)
  cases digest <;> simp [SealReceipt.output]

/-- The actual one-call KDF response determines both source material and the advanced kernel, including every later sealing failure. -/
inductive SendReceipt where
  | exhausted (kernel : ConcreteRatchetKernel)
  | attempted (pending : SendKdf RawCtxSourceSend.SealContext)
      (response : RatchetKdfResponse) (sealing : SealReceipt)

noncomputable def SendReceipt.output : SendReceipt → ConcreteRatchetKernel × Option RawCtxSourceSend.Encrypted
  | .exhausted kernel => (kernel, none)
  | .attempted pending response sealing =>
      let ready := RawCtxSourceSend.resumeSend pending response
      (ready.advanced, sealing.output.map (RawCtxSourceSend.encrypted (RawCtxSourceSend.arguments ready)))

/-- This executes the original begin/resume and native primitive requests. The receipt adds no call or alternate sampling of material/next-chain projections. -/
noncomputable def firstSend (kernel : ConcreteRatchetKernel) (context : RawCtxSourceSend.SealContext) :
    OracleComp RawCtxSourceSeal.NativeSpec SendReceipt :=
  match RawCtxSourceSend.beginSend kernel context with
  | .SendExhausted entry _ => pure (.exhausted entry)
  | .SendKdfRequested pending => do
      let response ← RawCtxSourceSeal.NativeSpec.query (.inl pending.request)
      let ready := RawCtxSourceSend.resumeSend pending response
      let receipt ← simulateQ sealLift (sealing (RawCtxSourceSend.arguments ready))
      pure (.attempted pending response receipt)

/-- Complete native first-send equality preserves the advanced private candidate and actual optional frame before either outer publication outcome. -/
theorem firstSend_erase (kernel : ConcreteRatchetKernel) (context : RawCtxSourceSend.SealContext) :
    SendReceipt.output <$> firstSend kernel context =
      simulateQ RawCtxSourceSeal.nativeAdapter
        (simulateQ RawCtxSourceSend.adapter (RawCtxSourceSend.send kernel context)) := by
  simp only [firstSend, RawCtxSourceSend.send]
  cases RawCtxSourceSend.beginSend kernel context <;>
    simp only [map_pure, SendReceipt.output, RawCtxSourceSend.program, simulateQ_pure]
  simp only [map_bind, simulateQ_bind, simulateQ_spec_query, RawCtxSourceSend.adapter,
    nativeAdapter, simulateQ_pure, bind_assoc, pure_bind]
  refine bind_congr (fun response => ?_)
  simp only [map_pure, SendReceipt.output, ← seal_erase, simulateQ_map, bind_map_left]

end BeaconcryptCore.Computational.PqxdhRegistrationTailPrimitives

/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailPrimitives.seal_erase' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailPrimitives.seal_erase
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailPrimitives.firstSend_erase' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailPrimitives.firstSend_erase
