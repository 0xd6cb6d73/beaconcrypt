import json
from pathlib import Path
p=Path('/tmp/bc-arc-scratch/merge-postgres-20261026/collection/axis-03-postgres-peers-1000-attempt-01/report.json')
r=json.loads(p.read_text())
selected=[x for x in r['results'] if x['scenario']=='burst_512' and x['arm'] in ('row','cached_row')]
root=Path(__file__).resolve().parent
(root/'original-bursts.json').write_text(json.dumps({'source':str(p),'results':selected})+'\n')
for x in selected:
 spans=[s for w in x['workers'] for s in w['db_spans']]
 print(x['trial'],x['arm'], {kind:round(sum(s['end_ns']-s['start_ns'] for s in spans if s['kind']==kind)/512/1e6,3) for kind in ('row_load','row_commit')})
