#!/usr/bin/env bash
set -euo pipefail
source /tmp/bc-arc-scratch/core-row-merge/env.sh
export PATH=/nix/store/2bq8r5zag09ngvxr3jnfxhww1x904psn-postgresql-16.15/bin:$PATH
pg_data=/tmp/bc-arc-scratch/merge-postgres-20261026/pgdata
initdb -D "$pg_data" -U bcbench --auth=trust --locale=C --encoding=UTF8
cat >> "$pg_data/postgresql.conf" <<'CONF'
listen_addresses = '127.0.0.1'
port = 55459
unix_socket_directories = ''
shared_buffers = '128MB'
max_connections = 32
fsync = on
synchronous_commit = on
full_page_writes = on
CONF
touch "$pg_data/BC_TEST_CLUSTER_ONLY"
trap 'pg_ctl -D "$pg_data" stop -m fast -w -t 30 > /tmp/bc-arc-scratch/merge-postgres-20261026/validation-pg-stop.log 2>&1 || true' EXIT
pg_ctl -D "$pg_data" -l /tmp/bc-arc-scratch/merge-postgres-20261026/validation-postgres.log start -w -t 30
export BEACONCRYPT_BENCH_POSTGRES='host=127.0.0.1 port=55459 user=bcbench dbname=postgres sslmode=disable'
export BC_PERSISTENCE_PG_DSN="$BEACONCRYPT_BENCH_POSTGRES"
export BC_PG_TEST_OWNED_DATA="$pg_data"
export BC_PG_TEST_PG_CTL=/nix/store/2bq8r5zag09ngvxr3jnfxhww1x904psn-postgresql-16.15/bin/pg_ctl
cargo test -p beaconcrypt --example persistence_bench --locked -- --include-ignored --test-threads=1
