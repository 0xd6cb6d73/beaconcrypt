import json
from pathlib import Path
root=Path(__file__).resolve().parent
p=root/'history/report.json'
r=json.loads(p.read_text());selected=[x for x in r['results'] if x['scenario']=='burst_512']
(root/'history/bursts.json').write_text(json.dumps({'results':selected})+'\n')
print('completed callbacks:',sum(x['messages'] for x in r['results']))
for x in selected: print(x['trial'],x['arm'],round(x['server_batch_ns']/1e6,3),'ms',sum(w['scheduler_runtime_ns'] for w in x['workers'])/1e6,'cpu ms')
