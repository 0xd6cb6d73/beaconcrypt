#!/usr/bin/env bash
set -euo pipefail
source /tmp/bc-arc-scratch/core-row-merge/env.sh
export BEACONCRYPT_BENCH_POSTGRES='host=127.0.0.1 port=55459 user=user dbname=bc_batch sslmode=disable'
runroot=/tmp/bc-arc-scratch/pg-batching-20261026
cd /home/user/worktrees/beaconcrypt-pg-batching
mkdir -p "$runroot/bench-2ms"
sha256sum "$CARGO_TARGET_DIR/release/examples/persistence_bench" > "$runroot/bench-2ms/binary.sha256"
date -u --iso-8601=seconds > "$runroot/bench-2ms/started.txt"
vmstat -w 1 > "$runroot/bench-2ms/vmstat.log" &
monitor_pid=$!
trap 'kill "$monitor_pid" 2>/dev/null || true' EXIT
# Allow the final build and mutation I/O to settle under the exclusive resource lease.
sleep 60
index=0
for batch in 1 8 8 1; do
 index=$((index+1))
 timeout 600 "$CARGO_TARGET_DIR/release/examples/persistence_bench" --run --backend postgres --mode concurrent --peers 1000 --active-peers 32 --workers 8 --trials 1 --period-ms 1000 --arrival-ms 1 --burst-chunks 512 --pg-batch-size "$batch" --pg-batch-wait-us 2000 --output "$runroot/bench-2ms/run-$index-batch-$batch.json" > "$runroot/bench-2ms/run-$index.log" 2>&1
 python3 beaconcrypt/examples/persistence_bench/summarize.py "$runroot/bench-2ms/run-$index-batch-$batch.json" --format json > "$runroot/bench-2ms/run-$index-summary.json"
done
date -u --iso-8601=seconds > "$runroot/bench-2ms/finished.txt"
