"""Hash reviewed build and validation inputs, excluding generated targets and historical evidence."""

import hashlib
from pathlib import Path
import subprocess


def source_hashes(workspace):
    workspace = Path(workspace)
    paths = (
        subprocess.check_output(["git", "ls-files", "-z"], cwd=workspace)
        .decode()
        .split("\0")
    )
    prefixes = (
        "beaconcrypt/src/",
        "beaconcrypt-core/src/",
        "beaconcrypt-parse/src/",
        "beaconcrypt-wasm/src/",
        "beaconcrypt/tests/",
        "beaconcrypt/examples/persistence_bench/",
        ".cargo/",
    )
    selected = [
        path
        for path in paths
        if path
        and (
            path.startswith(prefixes)
            or Path(path).name
            in (
                "Cargo.toml",
                "Cargo.lock",
                "build.rs",
                "rust-toolchain.toml",
                "rustfmt.toml",
            )
        )
    ]
    return {
        path: hashlib.sha256((workspace / path).read_bytes()).hexdigest()
        for path in sorted(selected)
    }
