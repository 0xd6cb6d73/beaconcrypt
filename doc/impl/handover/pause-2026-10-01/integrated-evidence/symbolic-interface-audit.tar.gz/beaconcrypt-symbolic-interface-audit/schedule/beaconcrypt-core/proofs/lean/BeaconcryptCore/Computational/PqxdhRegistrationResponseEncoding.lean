-- SPDX-License-Identifier: 0BSD
import BeaconcryptCore.Computational.PqxdhRegistrationIdentityProcess

/-! The actual registration binding bytes at the response-tail operation boundary. This file is a separate source consumer, not a replacement cryptographic or wire-serialization model. -/
open OracleComp OracleSpec CoreModels Aeneas
open Aeneas.Std hiding namespace core alloc
open RustM beaconcrypt_core PqxdhRefinement
set_option autoImplicit false
namespace BeaconcryptCore.Computational.PqxdhRegistrationResponseEncoding
open PqxdhServerRegistrationPublication

/-- Public identifier and authenticated-payload bytes on the bounded source image of the symbolic constructors. This does not give disjointness from arbitrary untyped byte strings. -/
def payloadBytes (identifier : U64) (plaintext : Pqxdh.Bytes) : Pqxdh.Bytes :=
  Pqxdh.LE64 identifier.val ++ plaintext

/-- Equality of two actual encoded payloads determines their typed U64 identifier and suffix. The proof uses the existing concrete eight-byte encoding, not a free-constructor axiom. -/
theorem payload_injective (left right : U64) (first second : Pqxdh.Bytes)
    (same : payloadBytes left first = payloadBytes right second) :
    left = right ∧ first = second := by
  exact ⟨UScalar.eq_of_val_eq (Pqxdh.LE64_inj left.bv.isLt right.bv.isLt
    (List.append_inj same (by simp)).1), (List.append_inj same (by simp)).2⟩

/-- The process binding and payload projections have exactly the source's fixed-width split. -/
theorem payload_split (identifier : U64) (plaintext : Pqxdh.Bytes) :
    (payloadBytes identifier plaintext).take 8 = Pqxdh.LE64 identifier.val ∧
      (payloadBytes identifier plaintext).drop 8 = plaintext := by
  simp [payloadBytes]

/-- An actual initial-response binding check agrees with the concrete identifier in that same opened payload. This is not a claim about arbitrary later-record outer identifiers. -/
theorem opened_identifier (candidate : pqxdh.BeaconRegistrationCandidate)
    (kernel : ratchet.concrete.ConcreteRatchetKernel)
    (reply : core.option.Option RawCtxWholeOwner.Decrypted)
    (staged : PqxdhBeaconPhase2Publication.Staged)
    (accepted : PqxdhBeaconPhase2Publication.afterOpening candidate kernel reply = some staged)
    (identifier : U64) (plaintext : Pqxdh.Bytes)
    (same : staged.opened.plaintext = payloadBytes identifier plaintext) :
    candidate.assigned_key_id = identifier ∧ staged.opened.plaintext.drop 8 = plaintext ∧ plaintext ≠ [] := by
  have checked := PqxdhRegistrationBeacon.opened_binding candidate kernel reply staged accepted
  exact ⟨UScalar.eq_of_val_eq (Pqxdh.LE64_inj candidate.assigned_key_id.bv.isLt identifier.bv.isLt
    (checked.2.2.1.symm.trans ((congrArg (List.take 8) same).trans (payload_split identifier plaintext).1))),
    (congrArg (List.drop 8) same).trans (payload_split identifier plaintext).2,
    fun empty => checked.2.2.2 (((congrArg (List.drop 8) same).trans
      (payload_split identifier plaintext).2).trans empty)⟩

/-- The original complete candidate tail with its source-proved eight-byte public identifier representation made explicit. All initialization, allocation and writer work stays in source order. -/
noncomputable def encodedTail {Metadata PeerMetadata Consumed : Type}
    (source : PqxdhJointKdfGame.FixedHkdfSha512NoSaltSource)
    (candidate : pqxdh.ServerRegistrationCandidate)
    (root : PqxdhSecretInputKdf.RootOutput) (data : Option Pqxdh.Bytes)
    (metadata : PeerMetadata) (state : State Metadata PeerMetadata Consumed) :
    OracleComp TailSpec (RustM (Option Response × State Metadata PeerMetadata Consumed)) := do
  let valid ← TailSpec.query (.inr (.checkIdentity candidate.beacon_identity_public_key))
  if !valid then pure (ok (none, state)) else do
    let reserved ← TailSpec.query (.inr .reservePeer)
    if !reserved then pure (ok (none, state)) else
      continueRust (BeaconcryptCore.Refinement.ServerTransactionRefinement.initializeCandidate candidate (PqxdhRootTableInitialization.rootArray root)
        (PqxdhRootTableInitialization.initialResponse source.crypto)) fun kernel => do
        let plaintext := data.getD registrationWitness
        if plaintext.isEmpty then pure (ok (none, state))
        else if 8 + plaintext.length ≤ Usize.max then do
          let allocated ← TailSpec.query (.inr (.reservePlaintext (8 + plaintext.length)))
          if !allocated then pure (ok (none, state)) else
            ok <$> afterInitialization candidate (payloadBytes candidate.key_id plaintext)
              kernel metadata state
        else pure (ok (none, state))

/-- Exact source binding construction removes no callback or failure branch from the complete tail. The public numeric representation is the actual U64 little-endian encoding. -/
theorem candidate_encoding {Metadata PeerMetadata Consumed : Type}
    (source : PqxdhJointKdfGame.FixedHkdfSha512NoSaltSource)
    (candidate : pqxdh.ServerRegistrationCandidate)
    (root : PqxdhSecretInputKdf.RootOutput) (data : Option Pqxdh.Bytes)
    (metadata : PeerMetadata) (state : State Metadata PeerMetadata Consumed) :
    candidateTail source candidate root data metadata state =
      encodedTail source candidate root data metadata state := by
  obtain ⟨binding, prepared, bytes⟩ := candidate_binding candidate
  simp only [candidateTail, encodedTail, payloadBytes, prepared, continueRust, bytes]

end BeaconcryptCore.Computational.PqxdhRegistrationResponseEncoding

/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationResponseEncoding.payload_injective' depends on axioms: [propext,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationResponseEncoding.payload_injective
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationResponseEncoding.payload_split' depends on axioms: [propext] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationResponseEncoding.payload_split
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationResponseEncoding.opened_identifier' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationResponseEncoding.opened_identifier
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationResponseEncoding.candidate_encoding' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationResponseEncoding.candidate_encoding
