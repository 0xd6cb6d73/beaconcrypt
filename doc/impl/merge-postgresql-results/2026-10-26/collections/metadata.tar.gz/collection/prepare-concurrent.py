"""Freeze the reviewed concurrent collection plan without starting any services or timing work."""

import argparse
import json
from pathlib import Path
import shlex
import shutil

from hybrid_guard import (
    COORD,
    CPU_LIMITS,
    check_build,
    command,
    digest,
    matches_instrumentation,
    processes,
    utc,
    write_new,
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-receipt", type=Path, required=True)
    parser.add_argument("--validation-receipt", type=Path, required=True)
    parser.add_argument("--collection-directory", type=Path, required=True)
    parser.add_argument("--postgres-cluster", type=Path, required=True)
    parser.add_argument("--instrumentation-policy", type=Path, required=True)
    parser.add_argument(
        "--workspace",
        type=Path,
        default=Path("/home/user/worktrees/beaconcrypt-concurrent-persistence"),
    )
    args = parser.parse_args()
    destination = args.collection_directory.resolve()
    if destination.exists():
        raise RuntimeError("collection directory must be new")
    if not command([COORD, "registry", "owner", str(destination)]).startswith(
        "codex\t"
    ):
        raise RuntimeError("collection must be inside registered Codex scratch")
    receipt = json.loads(args.build_receipt.read_text())
    validation = json.loads(args.validation_receipt.read_text())
    if validation.get("status") != "passed":
        raise RuntimeError("validation gate has not passed")
    if validation.get("source_commit") != receipt.get(
        "source_commit"
    ) or validation.get("source_sha256") != receipt.get("source_sha256"):
        raise RuntimeError(
            "validation and build receipts must bind the same complete source map and commit"
        )
    cluster = json.loads(args.postgres_cluster.read_text())
    identity = json.loads(args.instrumentation_policy.read_text())[
        "instrumentation_identity"
    ]
    if not matches_instrumentation(processes().get(identity["pid"], {}), identity):
        raise RuntimeError("exact controller identity no longer matches")
    configuration = dict(
        trials=3,
        extra_registrations=0,
        active_peers=32,
        small_bytes=1024,
        small_messages=1024,
        large_bytes=65536,
        large_messages=128,
        mixed_messages=1024,
        large_every=16,
        burst_chunk_bytes=512000,
        burst_chunks=[64, 256, 512],
        warmup_messages=16,
    )
    concurrent = dict(
        workers=8,
        period_ms=[1000, 100, 10, 5],
        arrival_ms=2000,
        queue_capacity=256,
        queue_bytes=16777216,
        deadline_ms=1000,
        drain_ms=600000,
        max_offered=20000,
        max_precomputed_bytes=536870912,
    )
    arguments = ["--mode", "concurrent"]
    for key, value in {**configuration, **concurrent}.items():
        arguments.extend(
            [
                "--" + key.replace("_", "-"),
                ",".join(map(str, value)) if isinstance(value, list) else str(value),
            ]
        )
    plan = {
        "schema_version": 1,
        "status": "prepared after validation; execution explicitly authorized by the task owner",
        "created_utc": utc(),
        "workspace": str(args.workspace.resolve()),
        "collection_directory": str(destination),
        "binary": receipt["binary"],
        "build_receipt": receipt,
        "build_receipt_path": str(args.build_receipt.resolve()),
        "build_receipt_sha256": digest(args.build_receipt),
        "validation_receipt_path": str(args.validation_receipt.resolve()),
        "validation_receipt_sha256": digest(args.validation_receipt),
        "measurement_policy": {
            "instrumentation_identity": identity,
            "host_noise": "Physical host Kubernetes activity is unavoidable. Record host steal; gate competing VM work, swap and monitor gaps.",
            "timing_selection": "Retain first complete validated uncontaminated attempt. Never retry or select on favorable timing.",
        },
        "postgres_cluster": cluster,
        "postgres_port": int(
            dict(part.split("=", 1) for part in shlex.split(cluster["dsn"]))["port"]
        ),
        "postgres_start_arguments": [
            "-D",
            cluster["data_directory"],
            "-c",
            "unix_socket_directories=",
        ],
        "postgres_binary_sha256": digest(
            Path(cluster["binary_directory"]) / "postgres"
        ),
        "postgres_config_sha256": {
            name: digest(Path(cluster["data_directory"]) / name)
            for name in ("postgresql.conf", "postgresql.auto.conf", "pg_hba.conf")
        },
        "axes": [
            {"backend": backend, "peers": peers}
            for backend, peers in [
                ("sqlite", 1),
                ("postgres", 1),
                ("postgres", 100),
                ("sqlite", 100),
                ("sqlite", 1000),
                ("postgres", 1000),
            ]
        ],
        "workload_arguments": arguments,
        "expected_config": configuration,
        "expected_concurrency": concurrent,
        "limits": dict(
            passive_quiet_seconds=180,
            reserved_quiet_seconds=60,
            sample_seconds=5,
            maximum_sample_gap_seconds=10,
            passive_wait_seconds=43200,
            axis_seconds=7200,
            maximum_attempts_per_axis=3,
            minimum_disk_free_bytes=50 * 1024**3,
        ),
        "cpu_limits": CPU_LIMITS,
        "cpu_definition": "Per-process /proc/PID/stat CPU deltas with PID/start-tick identity. Exact benchmark, owned PostgreSQL and recorded controller identities are exempt. No controller descendants are exempt. Unknown VM CPU >=0.25 core for one process or >=0.5 core in aggregate vetoes collection. Host steal is recorded only; swap and baseline continuity remain gated. Five-second snapshots cannot detect every short-lived process.",
        "retry_policy": "At most three attempts per fixed axis. Retry only after observed interference, a monitor gap or reservation contention. Preserve all attempts. Stop on benchmark, validation or runtime-limit failure.",
        "comparison": "Three persistence arms, three trials, balanced arm order within each scenario. Fixed schedules compare completed response latency, deadlines, backpressure, service, throughput and actual client-call overlap. Separate backend/population windows are not a randomized cross-window experiment.",
        "monitor_limits": "Quiet VM with unavoidable physical-host noise. No other active lease, waiter, proof job, recognized heavy process or unapproved PostgreSQL client. Generic process CPU/swap thresholds and ticket sequence checks supplement process snapshots.",
    }
    check_build(plan)
    destination.mkdir()
    for name in (
        "hybrid_guard.py",
        "run-quiet-hybrid.py",
        "wait-quiet-hybrid.py",
        "test_hybrid_guard.py",
        "prepare-concurrent.py",
    ):
        shutil.copy2(Path(__file__).with_name(name), destination / name)
    shutil.copy2(
        args.workspace / "beaconcrypt/examples/persistence_bench/summarize.py",
        destination / "summarize.py",
    )
    shutil.copy2(args.build_receipt, destination / "build-receipt.json")
    shutil.copy2(args.validation_receipt, destination / "validation-receipt.json")
    plan["machinery_sha256"] = {
        path.name: digest(path) for path in destination.glob("*.py")
    }
    write_new(destination / "collection-plan.json", plan)
    print("Prepared only:", destination / "collection-plan.json")


if __name__ == "__main__":
    main()
