import hashlib, json, os, subprocess, sys
from pathlib import Path
root=Path(__file__).resolve().parent
work=Path('/home/user/worktrees/beaconcrypt-core-row-merge')
sys.path.insert(0,str(root/'collection-tools'))
from hybrid_guard import processes, digest, utc
from source_hashes import source_hashes
build=json.loads((root/'build-receipt.json').read_text())
assert build['source_sha256']==source_hashes(work)
assert subprocess.check_output(['git','status','--porcelain'],cwd=work,text=True).strip()==''
assert '87 passed' in (root/'validation.log').read_text()
validation={'status':'passed','source_commit':build['source_commit'],'source_sha256':build['source_sha256'],'command':'cargo test -p beaconcrypt --example persistence_bench --locked -- --include-ignored --test-threads=1','log_sha256':digest(root/'validation.log'),'runtime_validation':'doc/impl/core-row-merge-validation.json','notes':'Existing benchmark tests on merge runtime; includes real PostgreSQL adapters, concurrent protocol tests and owned-cluster crash/restart. No benchmark harness changes.'}
(root/'validation-receipt.json').write_text(json.dumps(validation,indent=2)+'\n')
pg='/nix/store/2bq8r5zag09ngvxr3jnfxhww1x904psn-postgresql-16.15/bin'
cluster={'binary_directory':pg,'version':subprocess.check_output([pg+'/postgres','--version'],text=True).strip(),'data_directory':str(root/'pgdata'),'dsn':'host=127.0.0.1 port=55459 user=bcbench dbname=postgres sslmode=disable','purpose':'Dedicated fresh merge benchmark cluster; no production data'}
(root/'postgres-cluster.json').write_text(json.dumps(cluster,indent=2)+'\n')
proc=processes();p=proc[os.getpid()]
while '.codex-wrapped' not in p.get('executable',''):
 p=proc[p['ppid']]
identity={key:p[key] for key in ['pid','start_ticks','executable','cgroup']}
(root/'instrumentation-policy.json').write_text(json.dumps({'instrumentation_identity':identity},indent=2)+'\n')
subprocess.run([sys.executable,str(root/'collection-tools/prepare-concurrent.py'),'--build-receipt',str(root/'build-receipt.json'),'--validation-receipt',str(root/'validation-receipt.json'),'--collection-directory',str(root/'collection'),'--postgres-cluster',str(root/'postgres-cluster.json'),'--instrumentation-policy',str(root/'instrumentation-policy.json'),'--workspace',str(work)],check=True)
path=root/'collection/collection-plan.json';plan=json.loads(path.read_text())
plan['axes']=[{'backend':'postgres','peers':n} for n in [1,100,1000]]
plan['cpu_limits']['outside_process_cores']=1.0
plan['cpu_limits']['outside_aggregate_cores']=2.0
plan['cpu_definition']='Final prior PostgreSQL policy: reject outside process >=1 core or aggregate >=2 cores; record unavoidable physical-host noise and steal; retain other lease, recognized job, swap and monitor-gap gates.'
plan['purpose']='Run the existing concurrent PostgreSQL comparison on merge commit40f66d60, without SQLite or workload changes.'
path.write_text(json.dumps(plan,indent=2)+'\n')
print(path)
