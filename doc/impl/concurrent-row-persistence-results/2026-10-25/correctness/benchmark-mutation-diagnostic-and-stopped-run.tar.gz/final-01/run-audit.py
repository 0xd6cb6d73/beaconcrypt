#!/usr/bin/env python3
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source"
TOOLS = ROOT.parent / "tools"
RESTART = "native_postgres_tests::postgres_crash_restart_preserves_committed_receipt_and_discards_uncommitted_rows"
FILTER = f"not test(={RESTART})"
PG_BIN = Path("/nix/store/2bq8r5zag09ngvxr3jnfxhww1x904psn-postgresql-16.15/bin")
HELPER = Path("/home/user/worktrees/mythic-beaconcrypt-local-e2e/integration/mythic/run-local.py")
spec = importlib.util.spec_from_file_location("owned", HELPER)
owned = importlib.util.module_from_spec(spec)
spec.loader.exec_module(owned)
FLOOR = 50 * 1024**3
status = {"phase": "setup", "exit_code": None, "cleanup_errors": []}
children = []


def save():
    temporary = ROOT / "audit-status.next.json"
    temporary.write_text(json.dumps(status, indent=2) + "\n")
    temporary.replace(ROOT / "audit-status.json")


def monitor(process):
    while process.process.poll() is None:
        free = shutil.disk_usage(ROOT).free
        status["disk_available_bytes"] = free
        status["memory_current_bytes"] = int((scope / "memory.current").read_text())
        status["memory_peak_bytes"] = int((scope / "memory.peak").read_text())
        save()
        if free < FLOOR:
            raise RuntimeError("disk available crossed the 50 GiB floor; stopping owned audit")
        time.sleep(5)
    return process.process.returncode


def interrupted(signum, frame):
    raise KeyboardInterrupt(f"signal {signum}")


signal.signal(signal.SIGTERM, interrupted)
signal.signal(signal.SIGINT, interrupted)
relative_scope = Path("/proc/self/cgroup").read_text().strip().split("::", 1)[1]
scope = Path("/sys/fs/cgroup") / relative_scope.lstrip("/")
environment = dict(os.environ)
environment["PATH"] = ":".join([
    str(TOOLS),
    "/home/user/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin",
    "/home/user/.cargo/bin",
    "/nix/store/9wyldz5qids294k9h5qcg1f72i52jidi-gnumake-4.4.1/bin",
    environment["PATH"],
])
for key in ("BC_PG_TEST_OWNED_DATA", "BC_PG_TEST_PG_CTL", "CARGO_TARGET_DIR"):
    environment.pop(key, None)
environment.update({
    "CARGO_BUILD_JOBS": "1", "RUST_TEST_THREADS": "1", "GOMAXPROCS": "1",
    "CARGO_INCREMENTAL": "0", "CARGO_PROFILE_DEV_DEBUG": "0", "CARGO_PROFILE_TEST_DEBUG": "0",
    "CARGO_PROFILE_TEST_OPT_LEVEL": "1", "TMPDIR": str(ROOT / "tmp"), "CARGO_TERM_COLOR": "never",
    "RUSTFLAGS": "-C linker-features=-lld", "PROPTEST_CASES": "128", "PROPTEST_RNG_SEED": "104729",
    "NEXTEST_USER_CONFIG_FILE": "none", "NEXTEST_PROFILE": "default",
})
try:
    if shutil.disk_usage(ROOT).free < FLOOR:
        raise RuntimeError("less than 50 GiB free before audit")
    with (ROOT / "initdb.log").open("wb") as log:
        subprocess.run([str(PG_BIN / "initdb"), "-D", str(ROOT / "pgdata"), "-U", "bc_example_audit", "-A", "trust", "--no-locale"], stdout=log, stderr=subprocess.STDOUT, check=True)
    port = owned.free_port()
    postgres = owned.OwnedProcess("postgres", [str(PG_BIN / "postgres"), "-D", str(ROOT / "pgdata"), "-h", "127.0.0.1", "-p", str(port), "-c", "unix_socket_directories=", "-c", "max_connections=128"], environment, ROOT, interrupt=True)
    children.append(postgres)
    postgres.wait_listener(port)
    dsn = f"host=127.0.0.1 port={port} user=bc_example_audit dbname=postgres sslmode=disable"
    environment["BC_PERSISTENCE_PG_DSN"] = dsn
    environment["BEACONCRYPT_BENCH_POSTGRES"] = dsn
    status.update({"dsn": dsn, "scope": relative_scope, "phase": "baseline"})
    save()
    cargo_test_args = ["--example", "persistence_bench", "--", "--include-ignored", "--skip", "postgres_crash_restart_preserves_committed_receipt_and_discards_uncommitted_rows", "--test-threads=1"]
    baseline_command = ["cargo", "test", "--locked", "--manifest-path", str(SOURCE / "Cargo.toml"), "-p", "beaconcrypt", *cargo_test_args]
    baseline = owned.OwnedProcess("baseline", baseline_command, environment, ROOT)
    children.append(baseline)
    result = monitor(baseline)
    status["baseline_exit_code"] = result
    status["baseline_command"] = baseline_command
    if result:
        raise RuntimeError(f"original example baseline failed with {result}")
    selection_command = ["python3", str(ROOT / "capture-selection.py")]
    selection = owned.OwnedProcess("selection", selection_command, environment, ROOT)
    children.append(selection)
    selection_exit = monitor(selection)
    if selection_exit:
        raise RuntimeError(f"nextest exact selection check failed with {selection_exit}")
    status["selection_review"] = json.loads((ROOT / "selection-review.json").read_text())
    status["phase"] = "baseline_waiting_review"
    save()
    deadline = time.monotonic() + 300
    while not (ROOT / "continue-after-baseline").exists():
        if time.monotonic() > deadline:
            raise RuntimeError("baseline review marker did not arrive within five minutes")
        time.sleep(1)
    common_nextest = ["--locked", "--example=persistence_bench", f"--config-file={ROOT / 'nextest.toml'}", "--run-ignored=all", f"--filterset={FILTER}", "--test-threads=1", "--retries=0"]
    command = ["cargo", "mutants", "--no-config", "--manifest-path", str(SOURCE / "Cargo.toml"), "--package", "beaconcrypt", "--file", "beaconcrypt/examples/persistence_bench/**", "--jobs", "4", "--jobserver-tasks", "4", "--test-tool=nextest", "--test-workspace=false", "--cap-lints=false", "--copy-target=true", "--baseline", "run", "--build-timeout", "600", "--timeout-multiplier", "3", "--minimum-test-timeout", "120", *[f"--cargo-arg={arg}" for arg in common_nextest], "--output", str(ROOT / "results")]
    status.update({"phase": "mutating", "mutation_command": command})
    save()
    mutants = owned.OwnedProcess("mutants", command, environment, ROOT)
    children.append(mutants)
    status["exit_code"] = monitor(mutants)
    status["phase"] = "finished"
except BaseException as error:
    status.update({"phase": "failed", "error": repr(error), "exit_code": 1})
    raise
finally:
    for process in reversed(children):
        try:
            process.stop()
        except Exception as error:
            status["cleanup_errors"].append(f"{process.name}: {error}")
    status["processes"] = [{"name": p.name, "pid": p.pid, "start_ticks": p.start_ticks, "cgroup": p.cgroup, "cleanup_verified": p.cleanup_verified} for p in children]
    status["memory_peak_bytes"] = int((scope / "memory.peak").read_text())
    if status["cleanup_errors"]:
        status["exit_code"] = 1
    save()
raise SystemExit(status["exit_code"])
