import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
TOOLS = ROOT.parent / "tools"
RESTART = "native_postgres_tests::postgres_crash_restart_preserves_committed_receipt_and_discards_uncommitted_rows"
command = [
    "cargo", "nextest", "list", "--manifest-path", str(ROOT / "source/Cargo.toml"),
    "--package", "beaconcrypt", "--locked", "--example=persistence_bench",
    "--config-file", str(ROOT / "nextest.toml"), "--run-ignored=all",
    "--filterset", f"not test(={RESTART})", "--message-format=json",
]
with (ROOT / "nextest-list.json").open("wb") as output, (ROOT / "nextest-list.log").open("wb") as error:
    subprocess.run(command, stdout=output, stderr=error, check=True, timeout=240)
metadata = json.loads((ROOT / "nextest-list.json").read_text())
assert list(metadata["rust-suites"]) == ["beaconcrypt::example/persistence_bench"]
suite = metadata["rust-suites"]["beaconcrypt::example/persistence_bench"]
assert suite["kind"] == "example"
listed = subprocess.check_output([
    suite["binary-path"], "--list", "--include-ignored", "--skip", RESTART,
], text=True, timeout=60)
(ROOT / "libtest-list.txt").write_text(listed)
original = {line.removesuffix(": test") for line in listed.splitlines() if line.endswith(": test")}
selected = {name for name, test in suite["testcases"].items() if test["filter-match"]["status"] == "matches"}
excluded = {name for name, test in suite["testcases"].items() if test["filter-match"]["status"] != "matches"}
assert selected == original and selected, (selected - original, original - selected)
assert excluded == {RESTART}, excluded
review = {
    "status": "passed", "selection_count": len(selected), "selected": sorted(selected),
    "selected_ignored": sorted(name for name in selected if suite["testcases"][name]["ignored"]),
    "excluded": sorted(excluded), "original_example_only": True,
    "matches_original_libtest_selection": True,
    "nextest_list_sha256": hashlib.sha256((ROOT / "nextest-list.json").read_bytes()).hexdigest(),
    "libtest_list_sha256": hashlib.sha256(listed.encode()).hexdigest(),
}
(ROOT / "selection-review.json").write_text(json.dumps(review, indent=2) + "\n")
print(f"Selected exactly {len(selected)} original example tests; only dedicated restart excluded")
