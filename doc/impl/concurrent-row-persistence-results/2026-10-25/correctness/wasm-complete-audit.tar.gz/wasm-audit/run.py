import datetime
import gzip
import hashlib
import json
import os
import pathlib
import subprocess
import sys

workspace = pathlib.Path('/home/user/worktrees/beaconcrypt-concurrent-persistence')
session = pathlib.Path('/tmp/bc-arc-scratch/row-persistence-20261025')
audit = session / 'concurrent/wasm-audit'
os.chdir(workspace)
os.environ['PATH'] = ':'.join([
    '/home/user/.rustup/toolchains/1.97.1-x86_64-unknown-linux-gnu/bin',
    '/tmp/beaconcrypt-435-upgrade/wasm-tools/zig-x86_64-linux-0.17.0',
    '/home/user/.cargo/bin',
    '/nix/store/9wyldz5qids294k9h5qcg1f72i52jidi-gnumake-4.4.1/bin',
    os.environ['PATH'],
])
for variable in ['RUSTFLAGS', 'SODIUM_LIB_DIR', 'SODIUM_SHARED', 'SODIUM_USE_PKG_CONFIG', 'CARGO_TARGET_DIR']:
    os.environ.pop(variable, None)
os.environ.update({
    'CARGO_BUILD_JOBS': '1', 'RUST_TEST_THREADS': '1', 'GOMAXPROCS': '1',
    'CARGO_PROFILE_TEST_OPT_LEVEL': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
    'TMPDIR': str(audit), 'ZIG_GLOBAL_CACHE_DIR': str(session / 'zig-cache'),
    'GOCACHE': str(session / 'guest-go-cache'), 'PROPTEST_RNG_SEED': '104729',
    'CARGO_TERM_COLOR': 'never', 'PYTHONDONTWRITEBYTECODE': '1',
})
commands = []
started = datetime.datetime.now(datetime.timezone.utc).isoformat()

def run(command, output=None):
    disk = subprocess.check_output(['/tmp/bc-coord/coord.sh', 'disk', 'level'], text=True).strip()
    print('DISK:', disk, flush=True)
    if disk.startswith('STOP'):
        raise SystemExit('Coordinator disk STOP: no build started')
    print('RUN:', ' '.join(map(str, command)), flush=True)
    begin = datetime.datetime.now(datetime.timezone.utc).isoformat()
    if output is None:
        result = subprocess.run(command)
    else:
        with open(audit / output, 'wb') as stream:
            result = subprocess.run(command, stdout=stream)
    record = {'command': list(map(str, command)), 'start': begin, 'finish': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit': result.returncode, 'disk_before': disk}
    commands.append(record)
    (audit / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    print('EXIT:', result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

for command in [['git', 'rev-parse', 'HEAD'], ['rustc', '--version'], ['zig', 'version'], ['go', 'version'], ['cargo', 'mutants', '--version']]:
    print(subprocess.check_output(command, text=True).strip(), flush=True)
(audit / 'source-status.txt').write_bytes(subprocess.check_output(['git', 'status', '--short']))
(audit / 'source-diff.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary']))
files = subprocess.check_output(['rg', '--files', 'beaconcrypt/src', 'beaconcrypt-core/src', 'beaconcrypt-parse/src', 'beaconcrypt-wasm/src'], text=True).splitlines()
files += ['Cargo.toml', 'Cargo.lock', 'beaconcrypt/Cargo.toml', 'beaconcrypt-core/Cargo.toml', 'beaconcrypt-parse/Cargo.toml', 'beaconcrypt-wasm/Cargo.toml', 'beaconcrypt/build.rs', '.cargo/config.toml', '.cargo/mutants-wasm.toml', 'scripts/test-wasm.sh', 'scripts/wasm-toolchain.json']
source_hashes = {path: hashlib.sha256((workspace / path).read_bytes()).hexdigest() for path in sorted(set(files))}
(audit / 'source-hashes.json').write_text(json.dumps(source_hashes, indent=2) + '\n')
run(['bash', 'scripts/test-wasm.sh'])
base = ['cargo', 'mutants', '-p', 'beaconcrypt-wasm', '--test-workspace=false']
run(base + ['--config', '.cargo/mutants-wasm.toml', '--list', '--json'], 'selected-catalog.json')
run(base + ['--no-config', '--list', '--json'], 'complete-catalog.json')
run(['go', 'build', '-mod=readonly', '-buildvcs=false', '-o', str(audit / 'runner'), './scripts/wasm-test-runner'])
os.environ['CARGO_TARGET_WASM32_WASIP1_RUNNER'] = str(audit / 'runner')
run(base + ['--config', '.cargo/mutants-wasm.toml', '--copy-target=false', '--cargo-arg=--target=wasm32-wasip1', '--baseline=run', '--cap-lints=false', '--jobs=1', '--jobserver-tasks=1', '--timeout=300', '--build-timeout=900', '--output', str(audit / 'mutations')])
run(base + ['--config', '.cargo/mutants-wasm.toml', '--list', '--json'], 'selected-catalog-final.json')
final_hashes = {path: hashlib.sha256((workspace / path).read_bytes()).hexdigest() for path in source_hashes}
(audit / 'source-hashes-final.json').write_text(json.dumps(final_hashes, indent=2) + '\n')
source_stable = source_hashes == final_hashes
initial = json.loads((audit / 'selected-catalog.json').read_text())
final = json.loads((audit / 'selected-catalog-final.json').read_text())
complete = json.loads((audit / 'complete-catalog.json').read_text())
selected_names = {entry['name'] for entry in initial}
excluded = [entry for entry in complete if entry['name'] not in selected_names]
(audit / 'selection-receipt.json').write_text(json.dumps({'selected': len(initial), 'complete': len(complete), 'excluded': excluded, 'source_stable': source_stable, 'catalog_stable': initial == final}, indent=2) + '\n')
if not source_stable or initial != final:
    raise SystemExit('Source or selected catalog drifted during audit')
run(['python3', '-B', str(audit / 'diagnostic_classifier.py'), '--run', str(audit / 'mutations/mutants.out'), '--catalog', str(audit / 'selected-catalog.json'), '--expected-count', str(len(initial)), '--output', str(audit / 'final-receipt')])
for name in ['selected-catalog-final.json', 'selected-catalog.json', 'complete-catalog.json', 'mutations/mutants.out/outcomes.json', 'mutations/mutants.out/mutants.json']:
    path = audit / name
    if path.exists():
        path.with_suffix(path.suffix + '.gz').write_bytes(gzip.compress(path.read_bytes(), mtime=0))
summary = {'started': started, 'finished': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'fresh': True, 'iterate': False, 'copy_target': False, 'lease_mib': 3072, 'commands': commands}
(audit / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print('WASI validation and fresh mutation run complete', flush=True)
