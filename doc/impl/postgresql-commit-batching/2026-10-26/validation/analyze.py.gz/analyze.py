import json
import statistics
from pathlib import Path

root = Path(__file__).resolve().parent
measurements = []
for index, batch in enumerate([1, 8, 8, 1, 1, 8], 1):
    report = json.loads((root / f'bench/run-{index}-summary.json').read_text())
    group = next(g for g in report['groups'] if g['scenario'] == 'burst_512')
    trial = group['trials'][0]
    for arm in ['snapshot', 'row', 'cached_row']:
        value = trial[arm]
        measurements.append(dict(
            run=index, max_batch=batch, arm=arm,
            seconds=value['server_batch_ns'] / 1e9,
            throughput_decimal_MB_s=group['plaintext_bytes'] / value['server_batch_ns'] * 1000,
            transactions=value['database']['transactions'],
            network_exchanges=value['database']['network_exchanges'],
            response_p99_ms=value['callback_latency_ns']['response_ns']['p99'] / 1e6,
            deadline_met=value['deadline_met'], offered=value['offered'],
        ))
summary = []
for batch in [1, 8]:
    for arm in ['snapshot', 'row', 'cached_row']:
        values = [v for v in measurements if v['max_batch'] == batch and v['arm'] == arm]
        summary.append(dict(
            max_batch=batch, arm=arm,
            median_seconds=statistics.median(v['seconds'] for v in values),
            duration_range_seconds=[min(v['seconds'] for v in values), max(v['seconds'] for v in values)],
            median_MB_s=statistics.median(v['throughput_decimal_MB_s'] for v in values),
            transactions=[v['transactions'] for v in values],
            exchanges=[v['network_exchanges'] for v in values],
            mean_requests_per_transaction=sum(v['offered'] for v in values) / sum(v['transactions'] for v in values),
        ))
ratios = {}
for arm in ['row', 'cached_row']:
    by_run = {v['run']: v for v in measurements if v['arm'] == arm}
    paired = [by_run[a]['seconds'] / by_run[b]['seconds'] for a, b in [(1, 2), (4, 3), (5, 6)]]
    ratios[arm] = dict(unbatched_over_batched=paired, median=statistics.median(paired), range=[min(paired), max(paired)])
result = dict(measurements=measurements, summary=summary, paired_ratios=ratios,
              scope='Focused 512 x 512000-byte burst; 1000 registered peers, 32 active, 8 owners; three interleaved independent runs per batch setting. Other schedules have a 1ms offered horizon and are smoke coverage only.')
(root / 'bench/comparison.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(summary=summary, paired_ratios=ratios), indent=2))
