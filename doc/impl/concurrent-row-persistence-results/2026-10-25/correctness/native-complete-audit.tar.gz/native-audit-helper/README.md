# Native mutation final audit helper

This helper reads existing cargo-mutants files and runs no builds, tests, shell commands, or catalog generation. It makes no changes to source or input artifacts. Its default catalog is a frozen copy of the current 1,672 entries, including exact mutation diffs, captured from `hybrid/native-audit/mutants.out/mutants.json` on 2026-10-25. The decompressed catalog SHA256 is `4352d34290b370926619f747575903e0cfa9faff988321271aea1b18f4e80619`.

After the native audit finishes, run:

```bash
python3 /tmp/bc-arc-scratch/row-persistence-20261025/hybrid/native-audit-helper/finalize_native_audit.py --output /tmp/bc-arc-scratch/row-persistence-20261025/hybrid/native-final-receipt
```

The output directory must be new. Omitting `--output` prints the summary without writing anything. `--run`, `--catalog`, and `--expected-count` can override the defaults if a separately documented follow-up run has a new catalog. Do not override the catalog merely to hide a discrepancy.

Exit 0 means exact coverage with no findings, every unviable case supported by a normal Rust compilation error, and a finalized run. Exit 1 means review is required; the receipt still contains all findings. Exit 2 means input files or schema could not be read. An in-progress run fails with uncovered mutants and a missing final timestamp; the helper does not wait for completion. It also flags input changes during its read.

The receipt contains reproducible gzip archives of the expected catalog, run catalog, and outcomes; JSON plus gzip summaries, findings, unviable diagnostics, and an artifact manifest; and `SHA256SUMS` for the receipt files. The manifest records every outcome's log and diff SHA256; it does not duplicate the logs. Preserve the original `native-audit/mutants.out` directory alongside the receipt.

The checks reconcile exact mutant identity, catalog content, and applied diff; reject duplicate or unexpected catalog entries/outcomes; enumerate missed, timed-out, uncovered, or unknown outcomes; check aggregate counters and completion; and require successful compilation before a caught test failure. The absence of a baseline is recorded explicitly because this native run used `--baseline=skip`; preceding validation remains separate evidence. The helper does not independently verify source stability or regenerate the catalog.

A verified unviable case requires Rust source diagnostics, a Rust source location, and an ordinary Build/Check exit 101 with no test phase. The current observed source errors are E0277 (missing trait implementations such as `Default`), E0599 (unsupported generated associated functions such as `Zeroizing::from_iter`), E0061 (wrong arity), E0282 (type inference), E0080 (constant overflow), and E0015 (non-const calls in const functions). Other numbered Rust errors are recorded by code. A narrow set of unnumbered syntax/lifetime diagnostics is recognized; unfamiliar diagnostics require review.

Infrastructure diagnostics take precedence over source diagnostics. Disk exhaustion, memory failure, compiler ICE/panic, build-process signals, linker/tool failures, and dependency/network failures prevent classification as verified unviable. `statuses.Unviable` preserves cargo-mutants' raw label; only `verified_unviable` is eligible to count as a genuine uncompilable mutation. `unviable_requiring_review` includes infrastructure cases and missing or inconclusive logs. This is a conservative diagnostic classifier, so false positives require inspection rather than automatic dismissal. Embedded mutation source diffs are excluded from diagnostic scanning to prevent string literals from masquerading as failures.

The completed native run initially produced 11 unclassified source diagnostics. Manual review added three exact accepted headers: missing `vec` macro, arithmetic overflow, and `as usize <` generic-argument parse ambiguity. Six, three, and two outcomes respectively matched these groups. Forty synthetic classifier examples passed, including infrastructure failures overriding accepted source diagnostics. The reviewed receipt is `../native-final-reviewed-receipt`; the original failed receipt remains `../native-final-receipt`.
