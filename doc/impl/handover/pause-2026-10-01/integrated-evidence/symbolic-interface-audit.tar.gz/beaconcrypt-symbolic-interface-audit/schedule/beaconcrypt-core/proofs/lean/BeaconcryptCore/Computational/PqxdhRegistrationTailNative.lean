-- SPDX-License-Identifier: 0BSD
import BeaconcryptCore.Computational.PqxdhRegistrationResponseTail

/-! Concrete evaluation of the complete response observations in the original shared cache and successful-seal log. No receipt changes the native callback replies or authorizes admission. -/
open OracleComp OracleSpec CoreModels Aeneas
open Aeneas.Std hiding namespace core alloc
open RustM beaconcrypt_core ratchet ratchet.concrete PqxdhRefinement
set_option autoImplicit false
namespace BeaconcryptCore.Computational.PqxdhRegistrationTailNative
open PqxdhServerRegistrationPublication PqxdhRegistrationTailPrimitives
open PqxdhRegistrationResponseTail
open PqxdhServerAuthExperiment (Setup Codec Checks tailImpl nativeTail tailAux)
variable {ι KemSK Reader WireResponse : Type} {baseSpec : OracleSpec ι}

abbrev Logged := StateT (RawCtxSharedPrimitive.SharedState (List RawCtxSourceSend.SealContext)) ProbComp

/-- Original primitive, shared commitment-cache and optional writer callbacks. -/
noncomputable def actual (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse) (checks : Checks) :
    QueryImpl NativeSpec Logged :=
  PqxdhRegistrationProtocolState.registrationImpl setup.source codec.frameWrite (tailAux codec checks)

/-- The private detailed send receipt is observed once; the original successful-seal context is appended at the same boundary before erasure and outer writing. -/
noncomputable def sent (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse) (checks : Checks)
    (kernel : ConcreteRatchetKernel) (context : RawCtxSourceSend.SealContext) : Logged SendReceipt := do
  let receipt ← simulateQ (actual setup codec checks) (simulateQ primitiveLift (firstSend kernel context))
  Bind.bind (if receipt.output.2.isSome then
      modify fun state => (state.1 ++ [context], state.2) else pure ()) (fun _ => pure receipt)

/-- Removing the detailed send receipt recovers the actual source send and its original successful-seal log, including on inner failure. -/
theorem sent_erase (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse) (checks : Checks)
    (kernel : ConcreteRatchetKernel) (context : RawCtxSourceSend.SealContext) :
    SendReceipt.output <$> sent setup codec checks kernel context =
      simulateQ (tailImpl setup codec checks) (simulateQ sendLift
        (simulateQ RawCtxSourceSend.adapter (RawCtxSourceSend.send kernel context))) := by
  simp only [sent, map_bind, map_pure]
  rw [← bind_map_left SendReceipt.output _ (fun value =>
    Bind.bind (if value.2.isSome then modify fun state => (state.1 ++ [context], state.2)
      else pure ()) (fun _ => pure value))]
  rw [← simulateQ_map, ← simulateQ_map, firstSend_erase, primitive_send,
    ← QueryImpl.simulateQ_compose]
  by_cases exhausted : kernel.refined.control.send_sequence = core.num.U64.MAX
  · rw [RawCtxSourceSend.send_exhausted kernel context exhausted]
    simp
  · obtain ⟨pending, begun, _, carried, _, _, _, _, _, _⟩ :=
      RawCtxSourceSend.beginSend_fields kernel context exhausted
    simp only [RawCtxSourceSend.send, begun, RawCtxSourceSend.program, simulateQ_bind,
      simulateQ_pure, simulateQ_spec_query, sendLift, RawCtxSourceSend.adapter, bind_assoc, pure_bind]
    refine bind_congr (fun response => ?_)
    obtain ⟨stepped, _, ready⟩ := RawCtxSourceSend.resumeSend_fields pending response
    simp only [tailImpl, bind_assoc, ready, RawCtxSourceSend.arguments, carried, Option.isSome_map]
    refine bind_congr (fun encrypted => ?_)
    cases encrypted <;> simp

/-- The complete actual post-initialization continuation retains its detailed receipt alongside the unchanged source seal log and cache. -/
noncomputable def afterSource (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse)
    (checks : Checks) (prepared : pqxdh.ServerRegistrationCandidate)
    (authenticated : Pqxdh.Bytes) (kernel : ConcreteRatchetKernel) : Logged AfterReceipt := do
  let receipt ← sent setup codec checks kernel (firstContext prepared authenticated)
  let _ ← tailImpl setup codec checks (.inr (.erase authenticated))
  match receipt.output.2 with
  | none => pure ⟨receipt, none⟩
  | some encrypted => do
      let fields := responseFields prepared encrypted
      let written ← tailImpl setup codec checks (.inr (.write fields))
      pure ⟨receipt, some (fields, written)⟩

/-- Full source equality at the same native log/cache state, with erasure before the outer writer and original publication only on its Some reply. -/
theorem afterSource_erase {Metadata PeerMetadata Consumed : Type}
    (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse) (checks : Checks)
    (prepared : pqxdh.ServerRegistrationCandidate) (authenticated : Pqxdh.Bytes)
    (kernel : ConcreteRatchetKernel) (metadata : PeerMetadata)
    (state : State Metadata PeerMetadata Consumed) :
    AfterReceipt.output prepared metadata state <$> afterSource setup codec checks prepared authenticated kernel =
      simulateQ (tailImpl setup codec checks)
        (afterInitialization prepared authenticated kernel metadata state) := by
  simp only [afterSource, afterInitialization, map_bind, simulateQ_bind, simulateQ_spec_query]
  rw [← sent_erase]
  simp only [bind_map_left]
  refine bind_congr (fun receipt => bind_congr (fun erased => ?_))
  cases receipt.output.2 <;> simp only [map_pure, map_bind, simulateQ_pure, simulateQ_bind,
    simulateQ_spec_query, AfterReceipt.output]
  refine bind_congr (fun written => ?_)
  cases written <;> rfl

/-- Complete real-operation candidate interpretation at the actual native callback boundary. Its observation does not discard source diagnostics or alter any allocator/writer decision. -/
noncomputable def candidateSource (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse)
    (checks : Checks) (prepared : pqxdh.ServerRegistrationCandidate)
    (root : PqxdhSecretInputKdf.RootOutput) (data : Option Pqxdh.Bytes) : Logged (RustM CandidateReceipt) := do
  let valid ← tailImpl setup codec checks (.inr (.checkIdentity prepared.beacon_identity_public_key))
  if !valid then pure (ok .identityRefused) else do
    let reserved ← tailImpl setup codec checks (.inr .reservePeer)
    if !reserved then pure (ok .peerRefused) else
      PqxdhInitialGenericBuilder.continueRust (BeaconcryptCore.Refinement.ServerTransactionRefinement.initializeCandidate prepared
        (PqxdhRootTableInitialization.rootArray root)
        (PqxdhRootTableInitialization.initialResponse setup.source.crypto)) fun kernel => do
        let plaintext := data.getD registrationWitness
        if plaintext.isEmpty then pure (ok (.emptyPlaintext kernel))
        else if 8 + plaintext.length ≤ Usize.max then do
          let allocated ← tailImpl setup codec checks (.inr (.reservePlaintext (8 + plaintext.length)))
          if !allocated then pure (ok (.allocationRefused kernel plaintext)) else
            (fun receipt => ok (.attempted kernel plaintext receipt)) <$>
              afterSource setup codec checks prepared
                (PqxdhRegistrationResponseEncoding.payloadBytes prepared.key_id plaintext) kernel
        else pure (ok (.oversizedPlaintext kernel plaintext))

/-- Whole candidate execution, including the original successful-seal log and shared cache, projects exactly to the existing native tail on every reply branch. -/
theorem candidateSource_erase {Metadata PeerMetadata Consumed : Type}
    (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse) (checks : Checks)
    (prepared : pqxdh.ServerRegistrationCandidate) (root : PqxdhSecretInputKdf.RootOutput)
    (data : Option Pqxdh.Bytes) (metadata : PeerMetadata)
    (state : State Metadata PeerMetadata Consumed) :
    (fun result => CandidateReceipt.output prepared metadata state <$> result) <$>
        candidateSource setup codec checks prepared root data =
      simulateQ (tailImpl setup codec checks)
        (candidateTail setup.source prepared root data metadata state) := by
  rw [PqxdhRegistrationResponseEncoding.candidate_encoding]
  simp only [candidateSource, PqxdhRegistrationResponseEncoding.encodedTail, map_bind,
    simulateQ_bind, simulateQ_spec_query]
  refine bind_congr (fun valid => ?_)
  cases valid <;> simp [map_bind, simulateQ_bind, CandidateReceipt.output,
    RawCtxMaterialInterpretation.rust_map_ok]
  refine bind_congr (fun reserved => ?_)
  cases reserved <;> simp [CandidateReceipt.output, RawCtxMaterialInterpretation.rust_map_ok]
  cases BeaconcryptCore.Refinement.ServerTransactionRefinement.initializeCandidate prepared
      (PqxdhRootTableInitialization.rootArray root)
      (PqxdhRootTableInitialization.initialResponse setup.source.crypto) <;>
    simp only [PqxdhInitialGenericBuilder.continueRust, continueRust, map_pure, simulateQ_pure]
  all_goals try rfl
  split_ifs <;> simp only [map_pure, simulateQ_pure, RawCtxMaterialInterpretation.rust_map_ok,
    CandidateReceipt.output, map_bind, simulateQ_bind, simulateQ_spec_query]
  refine bind_congr (fun allocated => ?_)
  cases allocated <;> simp [simulateQ_map, ← afterSource_erase, Functor.map_map,
    CandidateReceipt.output, RawCtxMaterialInterpretation.rust_map_ok]

end BeaconcryptCore.Computational.PqxdhRegistrationTailNative

/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailNative.sent_erase' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailNative.sent_erase
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailNative.afterSource_erase' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailNative.afterSource_erase
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailNative.candidateSource_erase' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailNative.candidateSource_erase
