-- SPDX-License-Identifier: 0BSD
import BeaconcryptCore.Computational.PqxdhRegistrationTailProcess
import BeaconcryptCore.Computational.PqxdhRegistrationProcessControl

/-! Actual response callback events on the source-value image, consumed by the existing canonical dispatcher run. The private events do not authorize admission and do not assert the symbolic cryptographic term equations. -/
open OracleComp OracleSpec CoreModels Aeneas
open Aeneas.Std hiding namespace core alloc
open RustM beaconcrypt_core ratchet ratchet.concrete PqxdhRefinement
set_option autoImplicit false
namespace BeaconcryptCore.Computational.PqxdhRegistrationTailEvents
open PqxdhServerRegistrationPublication PqxdhRegistrationTailPrimitives PqxdhRegistrationResponseTail
open PqxdhRegistrationTailOperations PqxdhRegistrationTailCallback PqxdhRegistrationTailProcess
open PqxdhJointIdentity PqxdhJointGapDh PqxdhServerAuthExperiment PqxdhServerAuthNative
variable {ι KemSK Reader WireResponse : Type} {baseSpec : OracleSpec ι}

/-- These are private observations of the same reached values and optional results. `completed` records the actual public return. Native diagnostics remain distinct from the seven ordinary refusal stages. -/
inductive Event where
  | prepared (candidate : pqxdh.ServerRegistrationCandidate) (root : PqxdhSecretInputKdf.RootOutput)
      (kernel : ConcreteRatchetKernel)
  | innerWritten (candidate : pqxdh.ServerRegistrationCandidate) (sent : SendReceipt)
      (frame : RawCtxSourceSend.Encrypted)
  | installed (candidate : pqxdh.ServerRegistrationCandidate) (kernel : ConcreteRatchetKernel)
  | published (candidate : pqxdh.ServerRegistrationCandidate) (response : Response)
  | refused (receipt : Option (RustM Receipt))
  | completed (response : Option Response)

/-- A source candidate that reached initialization retains that actual initialized kernel even if plaintext, allocation or a later writer is refused. -/
def initialized : CandidateReceipt → Option ConcreteRatchetKernel
  | .identityRefused | .peerRefused => none
  | .emptyPlaintext kernel | .oversizedPlaintext kernel _ | .allocationRefused kernel _ => some kernel
  | .attempted kernel _ _ => some kernel

/-- This projection reports reached private stages in source order. The erase operation is executed in the interpreted source; it is not elided by this event projection. -/
noncomputable def candidateEvents (root : PqxdhSecretInputKdf.RootOutput)
    (candidate : pqxdh.ServerRegistrationCandidate) (receipt : CandidateReceipt) : List Event :=
  (initialized receipt).toList.map (Event.prepared candidate root) ++
    match receipt with
    | .attempted _ _ after =>
        (after.sent.output.2.toList.map (Event.innerWritten candidate after.sent)) ++
          match after.written with
          | some (_, some bytes) => [Event.installed candidate after.sent.output.1,
              Event.published candidate ⟨bytes, candidate.key_id⟩]
          | _ => []
    | _ => []

/-- Only a normal candidate continuation contributes prepared/inner/install/publication observations. The complete native diagnostic or refused call remains separately visible to private analysis. -/
noncomputable def callEvents (receipt : CallReceipt) : List Event :=
  match receipt.receipt with
  | .ok (.candidate candidate actual) => candidateEvents receipt.token.root candidate actual
  | _ => []

/-- Every callback has one completion, including missing/future/spent indices and every source failure. Its private receipt is never added to the adversary's reply. -/
noncomputable def events (reply : Option Response) (receipt : Option CallReceipt) : List Event :=
  receipt.toList.flatMap callEvents ++
    (if reply.isSome then [] else [Event.refused (receipt.map CallReceipt.receipt)]) ++
    [Event.completed reply]

def Event.publication : Event → Option Response
  | .published _ response => some response
  | _ => none

/-- The publication observations are exactly the returned source response, including its original assigned identifier. Refusal contributes no publication observation. -/
theorem candidate_publications {Metadata PeerMetadata Consumed : Type}
    (root : PqxdhSecretInputKdf.RootOutput) (candidate : pqxdh.ServerRegistrationCandidate)
    (receipt : CandidateReceipt) (metadata : PeerMetadata) (state : State Metadata PeerMetadata Consumed) :
    (candidateEvents root candidate receipt).filterMap Event.publication =
      (receipt.output candidate metadata state).1.toList := by
  cases receipt <;> simp only [candidateEvents, initialized, CandidateReceipt.output,
    Option.toList_none, Option.toList_some, List.map_nil, List.map_cons, List.nil_append,
    List.filterMap_nil, List.filterMap_cons, Event.publication, List.filterMap_append]
  simp only [List.filterMap_map, Function.comp_def, Event.publication, List.filterMap_none, List.nil_append]
  case attempted kernel plaintext receipt =>
    rcases receipt with ⟨sent, _ | ⟨fields, _ | bytes⟩⟩ <;> rfl

/-- Reading a private call receipt yields precisely the ordinary source publication, with native fail/div and every ordinary refusal contributing no published response. -/
theorem call_publications (call : CallReceipt)
    (state : State Unit Unit (List Pqxdh.Bytes)) :
    (callEvents call).filterMap Event.publication =
      (settle state (Receipt.output () state <$> call.receipt)).1.toList := by
  cases actual : call.receipt <;> simp only [callEvents, actual]
  case ok receipt =>
    cases receipt <;> first | exact candidate_publications _ _ _ () state | rfl
  all_goals rfl

/-- Terminal observations retain the actual native diagnostic/refusal receipt separately from the public optional completion. -/
def Event.terminal : Event → Option (Sum (Option (RustM Receipt)) (Option Response))
  | .refused receipt => some (.inl receipt)
  | .completed reply => some (.inr reply)
  | _ => none

private theorem candidate_terminals (root : PqxdhSecretInputKdf.RootOutput)
    (candidate : pqxdh.ServerRegistrationCandidate) (receipt : CandidateReceipt) :
    (candidateEvents root candidate receipt).filterMap Event.terminal = [] := by
  cases receipt <;> simp only [candidateEvents, initialized,
    Option.toList_none, Option.toList_some, List.map_nil, List.map_cons, List.nil_append,
    List.filterMap_nil, List.filterMap_cons, Event.terminal, List.filterMap_append,
    List.filterMap_map, Function.comp_def, List.filterMap_none]
  case attempted kernel plaintext receipt =>
    rcases receipt with ⟨sent, _ | ⟨fields, _ | bytes⟩⟩ <;> rfl

private theorem call_terminals (call : CallReceipt) :
    (callEvents call).filterMap Event.terminal = [] := by
  cases actual : call.receipt <;> simp only [callEvents, actual]
  case ok receipt =>
    cases receipt <;> first | exact candidate_terminals _ _ _ | rfl
  all_goals rfl

/-- Every actual event list terminates with precisely one original completion. On refusal it first retains the same optional native diagnostic; success adds no refusal event. -/
theorem events_terminals (reply : Option Response) (receipt : Option CallReceipt) :
    (events reply receipt).filterMap Event.terminal =
      (if reply.isSome then [] else [Sum.inl (receipt.map CallReceipt.receipt)]) ++ [Sum.inr reply] := by
  cases receipt <;> simp only [events, Option.toList_none, Option.toList_some,
    List.flatMap_nil, List.flatMap_cons, List.append_nil, List.filterMap_append,
    call_terminals, List.nil_append]
  all_goals split_ifs <;> rfl

/-- The receipt uses the actual looked-up token and request. Its public reply and installed Server are the original settlement of the same complete native result. An absent receipt is precisely the missing-slot branch. -/
def CallRelation {A : Type} (before : PqxdhRegistrationTableDispatcher.State KemSK A)
    (index : Nat) (payload : Option Pqxdh.Bytes) (reply : Option Response)
    (receipt : Option CallReceipt) (after : PqxdhRegistrationTableDispatcher.State KemSK A) : Prop :=
  match receipt with
  | none => reply = none ∧ PqxdhRegistrationBuildLookup.available before.2 index = none ∧
      after = PqxdhRegistrationTableDispatcher.clear before
  | some call => call.session = index ∧ call.payload = payload ∧
      PqxdhRegistrationBuildLookup.available before.2 index = some call.token ∧
      let old := (PqxdhRegistrationTableDispatcher.restore before).2.shared.2.server
      let result := settle old (Receipt.output () old <$> call.receipt)
      reply = result.1 ∧ (PqxdhRegistrationTableDispatcher.restore after).2.shared.2.server = result.2

/-- On an actual source-related callback, there is exactly one publication event iff the public response is returned, with the same bytes and assigned identifier. Earlier inner-frame success cannot supply this event by itself. -/
theorem events_publications {A : Type} (before : PqxdhRegistrationTableDispatcher.State KemSK A)
    (index : Nat) (payload : Option Pqxdh.Bytes) (reply : Option Response)
    (receipt : Option CallReceipt) (after : PqxdhRegistrationTableDispatcher.State KemSK A)
    (related : CallRelation before index payload reply receipt after) :
    (events reply receipt).filterMap Event.publication = reply.toList := by
  cases receipt <;> simp only [CallRelation] at related
  case some call =>
    simp only [events, Option.toList_some, List.flatMap_cons, List.flatMap_nil, List.append_nil, List.filterMap_append]
    split_ifs <;> simpa only [List.filterMap_nil, List.filterMap_cons, Event.publication, List.append_nil] using
      (call_publications call (PqxdhRegistrationTableDispatcher.restore before).2.shared.2.server).trans
        (congrArg Option.toList related.2.2.2.1.symm)
  all_goals simp only [related.1, events, Option.toList_none, List.flatMap_nil, Option.isSome_none, Bool.false_eq_true, ite_false, Option.map_none, List.nil_append, List.filterMap_append, List.filterMap_cons, List.filterMap_nil, Event.publication]

/-- The complete observed callback derives its event/return relation on every source support path, without assuming writer success or a valid present token. -/
theorem build_relation {A : Type} (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse)
    (checks : Checks) (index : Nat) (payload : Option Pqxdh.Bytes) (encoded : Pqxdh.Bytes)
    (before : PqxdhRegistrationTableDispatcher.State KemSK A) (reply : Option Response)
    (receipt : Option CallReceipt) (after : PqxdhRegistrationTableDispatcher.State KemSK A)
    (supported : ((reply, receipt), after) ∈ support
      (PqxdhRegistrationTailCallback.build setup codec checks index payload encoded before)) :
    CallRelation before index payload reply receipt after := by
  unfold PqxdhRegistrationTailCallback.build at supported
  cases available : PqxdhRegistrationBuildLookup.available before.2 index <;>
    simp only [available, mem_support_pure_iff, support_map, Set.mem_image] at supported
  case some token =>
    obtain ⟨value, reached, equal⟩ := supported
    simp only [present, support_map, Set.mem_image] at reached
    obtain ⟨tail, actual, rfl⟩ := reached
    simp only [Prod.mk.injEq] at equal
    rcases equal with ⟨⟨rfl, rfl⟩, rfl⟩
    exact ⟨rfl, rfl, available, rfl, rfl⟩
  all_goals simp_all only [Prod.mk.injEq, CallRelation, and_self]

/-- At an actually reachable table state, each supported callback has a same-execution private source receipt and realizes the original generated canonical control run. The full nine-class public interface is unchanged. -/
theorem callback_run {A Result : Type} (setup : Setup baseSpec KemSK) (codec : Codec Reader WireResponse)
    (checks : Checks) (ensureInit : StateT A ProbComp Bool) (supplied : Option Pqxdh.Bytes)
    (adversary : PublicIdentity → U64 → OracleComp PqxdhRegistrationSchedule.SurfaceSpec Result)
    (runtime afterRuntime : A) (created : PqxdhLiveServerConstruction.Created Unit)
    (answer : Result) (state : PqxdhRegistrationSchedule.State KemSK)
    (table : PqxdhRegistrationPendingTables.PendingTable)
    (reached : (some (created, answer, state, table), afterRuntime) ∈ support
      (PqxdhRegistrationTableDispatcher.experiment setup codec checks ensureInit supplied adversary runtime))
    (index : Nat) (payload : Option Pqxdh.Bytes)
    (reply : Option Response) (after : PqxdhRegistrationTableDispatcher.State KemSK A)
    (supported : (reply, after) ∈ support
      ((PqxdhRegistrationTableDispatcher.handler setup codec checks created.seed ensureInit
        (PqxdhRegistrationBuildLookup.buildQuery index payload)).run ((afterRuntime, state), table))) :
    ∃ encoded receipt,
      ((reply, receipt), after) ∈ support
        (PqxdhRegistrationTailCallback.build setup codec checks index payload encoded ((afterRuntime, state), table)) ∧
      CallRelation ((afterRuntime, state), table) index payload reply receipt after ∧
      (events reply receipt).filterMap Event.publication = reply.toList ∧
      PqxdhRegistrationProcessControl.Run PqxdhRegistrationProcessControl.program
        (PqxdhRegistrationTableDispatcher.handler setup codec checks created.seed ensureInit)
        ⟨((afterRuntime, state), table), .idle, []⟩
        [⟨PqxdhRegistrationBuildLookup.buildQuery index payload, reply⟩] 4 ⟨after, .idle, []⟩ ∧
      (PqxdhRegistrationTailCallback.build setup codec checks index payload encoded
        ((afterRuntime, state), table)).IsTotalQueryBound 64 := by
  obtain ⟨encoded, same, bounded⟩ := PqxdhRegistrationTailCallback.table_callback setup codec checks ensureInit
    supplied adversary runtime afterRuntime created answer state table reached index payload
  have original := supported
  rw [← same] at supported
  change (reply, after) ∈ support ((fun result => (result.1.1, result.2)) <$>
    PqxdhRegistrationTailCallback.build setup codec checks index payload encoded ((afterRuntime, state), table)) at supported
  rw [support_map] at supported
  obtain ⟨⟨⟨_, receipt⟩, _⟩, supported, equal⟩ := supported
  obtain ⟨rfl, rfl⟩ := Prod.mk.inj equal
  have related := build_relation setup codec checks index payload encoded _ _ _ _ supported
  exact ⟨encoded, receipt, supported, related, events_publications _ index payload _ receipt _ related,
    PqxdhRegistrationProcessControl.callback_run _ PqxdhRegistrationProcessControl.program_wrapper
      _ _ _ _ _ original, bounded⟩

end BeaconcryptCore.Computational.PqxdhRegistrationTailEvents

/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailEvents.candidate_publications' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailEvents.candidate_publications
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailEvents.call_publications' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailEvents.call_publications
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailEvents.events_terminals' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailEvents.events_terminals
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailEvents.events_publications' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailEvents.events_publications
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailEvents.build_relation' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailEvents.build_relation
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTailEvents.callback_run' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTailEvents.callback_run
