-- SPDX-License-Identifier: 0BSD
import BeaconcryptCore.Computational.PqxdhRegistrationPendingSurface

/-! An executable pending-table dispatcher reconstructs the current native map from immutable rows and used entries. Its stored native pending field is cleared between operations; only the current table view is supplied to the original source callbacks. -/
open OracleComp OracleSpec CoreModels Aeneas
open Aeneas.Std hiding namespace core alloc
open RustM beaconcrypt_core PqxdhRefinement
set_option autoImplicit false
namespace BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher
open PqxdhJointIdentity PqxdhJointGapDh PqxdhServerAuthExperiment PqxdhServerAuthNative
open PqxdhRegistrationPendingTables
variable {ι : Type} {baseSpec : OracleSpec ι} {KemSK Reader Response A Result : Type}

abbrev State (KemSK A : Type) := (A × PqxdhRegistrationSchedule.State KemSK) × PendingTable

def install (source : PqxdhRegistrationSchedule.State KemSK)
    (pending : Nat → Option PqxdhServerRelatedRootConsumer.Returned) : PqxdhRegistrationSchedule.State KemSK :=
  { source with shared := (source.shared.1, { source.shared.2 with pending := pending }) }

/-- The source projection reconstructs only current tokens. It ignores the redundant native pending field and leaves all other source/runtime/cache fields unchanged. -/
def restore (state : State KemSK A) : A × PqxdhRegistrationSchedule.State KemSK :=
  (state.1.1, install state.1.2 state.2.current)

/-- Clear the redundant native current-map field after the private tables have been updated from the actual operation. No other source field or historical table is cleared. -/
def clear (state : State KemSK A) : State KemSK A :=
  ((state.1.1, install state.1.2 (fun _ => none)), state.2)

/-- Clearing the unused native map has no effect on the source projection: every currently available token is determined by the row/used tables. -/
theorem restore_clear (state : State KemSK A) : restore (clear state) = restore state := by
  rfl

/-- On the actually established source/table invariant, reconstructing the current map recovers every original source field exactly. -/
theorem restore_valid (state : State KemSK A) (valid : SurfaceValid state) : restore state = state.1 := by
  simp only [restore, install, valid.1.2]

/-- The table-backed state requires only unique allocated indices; its actual current token values are supplied by the table view. -/
def Good (state : State KemSK A) : Prop :=
  state.2.Below state.1.2.shared.2.sessions ∧ state.2.Unique

def prepared (state : State KemSK A) : State KemSK A := (restore state, state.2)

/-- The source callback input uses precisely the table's current map. This relation does not assume equality with an independently stored current map. -/
theorem prepared_valid (state : State KemSK A) (good : Good state) : SurfaceValid (prepared state) := by
  exact ⟨⟨good.1, rfl⟩, good.2⟩

/-- Run the literal source callback with its current map reconstructed from the table. Its actual result updates the private rows/used list, then the redundant native map is cleared before the next request. -/
noncomputable def handler (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (seed : IdentitySeed) (ensureInit : StateT A ProbComp Bool) :
    QueryImpl PqxdhRegistrationSchedule.SurfaceSpec (StateT (State KemSK A) ProbComp) :=
  fun query state => (fun result => (result.1, clear result.2)) <$>
    (observedSurface setup codec checks seed ensureInit query).run (prepared state)

/-- Every callback result stores an empty redundant native map. Later availability tests therefore use the historical rows and used entries rather than a retained second map. -/
theorem handler_cleared (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (seed : IdentitySeed) (ensureInit : StateT A ProbComp Bool)
    (query : PqxdhRegistrationSchedule.SurfaceSpec.Domain) (state : State KemSK A)
    (result : PqxdhRegistrationSchedule.SurfaceSpec.Range query × State KemSK A)
    (supported : result ∈ support ((handler setup codec checks seed ensureInit query).run state)) :
    result.2.1.2.shared.2.pending = fun _ => none := by
  simp only [handler, StateT.run, support_map, Set.mem_image] at supported
  obtain ⟨source, _, rfl⟩ := supported
  rfl

/-- The actual source operation supplies the next allocated, unique tables. Clearing the redundant native map changes none of the counter or table invariants. -/
theorem handler_good (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (seed : IdentitySeed) (ensureInit : StateT A ProbComp Bool)
    (query : PqxdhRegistrationSchedule.SurfaceSpec.Domain) (state : State KemSK A)
    (result : PqxdhRegistrationSchedule.SurfaceSpec.Range query × State KemSK A)
    (good : Good state)
    (supported : result ∈ support ((handler setup codec checks seed ensureInit query).run state)) :
    Good result.2 := by
  simp only [handler, StateT.run, support_map, Set.mem_image] at supported
  obtain ⟨source, reached, rfl⟩ := supported
  have valid := surface_valid setup codec checks seed ensureInit query (prepared state) source
    (prepared_valid state good) reached
  exact ⟨valid.1.1, valid.2⟩

/-- Table-driven pending availability gives exactly the original source operation under the complete reconstructed-state projection. No successful lookup, origin or callback-security premise is supplied. -/
theorem handler_source (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (seed : IdentitySeed) (ensureInit : StateT A ProbComp Bool)
    (query : PqxdhRegistrationSchedule.SurfaceSpec.Domain) (state : State KemSK A)
    (good : Good state) :
    (fun result => (result.1, restore result.2)) <$> (handler setup codec checks seed ensureInit query).run state =
      (PqxdhRegistrationSchedule.surfaceHandler setup codec checks seed ensureInit query).run (restore state) := by
  refine Eq.trans ?_ (surface_source setup codec checks seed ensureInit query (prepared state))
  simp only [handler, StateT.run, ← bind_pure_comp, bind_assoc, pure_bind]
  apply bind_congr_of_forall_mem_support
  intro result supported
  rw [restore_clear, restore_valid result.2
    (surface_valid setup codec checks seed ensureInit query (prepared state) result (prepared_valid state good) supported)]

/-- Exact table-driven/source correspondence lifts through every adaptive raw request and its original continuation. The reconstructed current map and all other source/runtime/cache fields form one common state projection. -/
theorem program_source (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (seed : IdentitySeed) (ensureInit : StateT A ProbComp Bool)
    (work : OracleComp PqxdhRegistrationSchedule.SurfaceSpec Result) (state : State KemSK A)
    (good : Good state) :
    (fun result => (result.1, restore result.2)) <$>
      (simulateQ (handler setup codec checks seed ensureInit) work).run state =
        (simulateQ (PqxdhRegistrationSchedule.surfaceHandler setup codec checks seed ensureInit) work).run (restore state) := by
  exact map_run_simulateQ_eq_of_query_map_eq_inv'
    (handler setup codec checks seed ensureInit)
    (PqxdhRegistrationSchedule.surfaceHandler setup codec checks seed ensureInit)
    Good restore
    (fun query before invariant after reached => handler_good setup codec checks seed ensureInit query before after invariant reached)
    (handler_source setup codec checks seed ensureInit) work state good

/-- All actual adaptive table-driven executions preserve allocated unique indices, including failed and future public requests. -/
theorem program_good (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (seed : IdentitySeed) (ensureInit : StateT A ProbComp Bool)
    (work : OracleComp PqxdhRegistrationSchedule.SurfaceSpec Result) (state : State KemSK A)
    (good : Good state) (result : Result × State KemSK A)
    (supported : result ∈ support ((simulateQ (handler setup codec checks seed ensureInit) work).run state)) :
    Good result.2 := by
  exact simulateQ_run_preserves_inv_of_query (handler setup codec checks seed ensureInit) Good
    (fun query before invariant after reached => handler_good setup codec checks seed ensureInit query before after invariant reached)
    work state good result supported

/-- The actual constructed Server has no available or historical token. Its complete owner/runtime/cache state is retained. -/
def initial (created : PqxdhLiveServerConstruction.Created Unit) (runtime : A) : State KemSK A :=
  ((runtime, PqxdhRegistrationSchedule.initial created), Table.empty)

/-- Literal initialization establishes the table invariant without assuming any successful later registration. -/
theorem initial_good (created : PqxdhLiveServerConstruction.Created Unit) (runtime : A) :
    Good (initial (KemSK := KemSK) created runtime) := by
  exact ⟨(initial_valid (KemSK := KemSK) created).1.1, (initial_valid (KemSK := KemSK) created).2⟩

/-- Reconstructing the initially empty table leaves the actual native constructor result and complete runtime unchanged. -/
theorem initial_restore (created : PqxdhLiveServerConstruction.Created Unit) (runtime : A) :
    restore (initial (KemSK := KemSK) created runtime) = (runtime, PqxdhRegistrationSchedule.initial created) := by
  exact restore_valid _ (initial_valid (KemSK := KemSK) created)

/-- Start the complete table-driven raw schedule from the actual constructed Server. The public adversary input is unchanged. -/
noncomputable def tableExecute (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (ensureInit : StateT A ProbComp Bool)
    (adversary : PublicIdentity → Std.U64 → OracleComp PqxdhRegistrationSchedule.SurfaceSpec Result)
    (created : PqxdhLiveServerConstruction.Created Unit) (runtime : A) : ProbComp (Result × State KemSK A) :=
  (simulateQ (handler setup codec checks created.seed ensureInit)
    (adversary created.publicIdentity created.server.server.metadata.sender)).run (initial created runtime)

/-- Complete initialized execution agrees with the original raw source program, including every adversarial continuation and current token in the projected native state. -/
theorem execute_source (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (ensureInit : StateT A ProbComp Bool)
    (adversary : PublicIdentity → Std.U64 → OracleComp PqxdhRegistrationSchedule.SurfaceSpec Result)
    (created : PqxdhLiveServerConstruction.Created Unit) (runtime : A) :
    (fun result => (result.1, restore result.2)) <$> tableExecute setup codec checks ensureInit adversary created runtime =
      PqxdhRegistrationSchedule.surfaceExecute setup codec checks ensureInit adversary created runtime := by
  simpa only [initial_restore, tableExecute, PqxdhRegistrationSchedule.surfaceExecute] using program_source setup codec checks created.seed ensureInit
    (adversary created.publicIdentity created.server.server.metadata.sender) (initial created runtime)
    (initial_good created runtime)

/-- Every complete initialized execution establishes the table invariant from the actual empty source state, with no caller-supplied row or availability premise. -/
theorem execute_good (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (ensureInit : StateT A ProbComp Bool)
    (adversary : PublicIdentity → Std.U64 → OracleComp PqxdhRegistrationSchedule.SurfaceSpec Result)
    (created : PqxdhLiveServerConstruction.Created Unit) (runtime : A)
    (result : Result × State KemSK A)
    (supported : result ∈ support (tableExecute setup codec checks ensureInit adversary created runtime)) :
    Good result.2 := by
  exact program_good setup codec checks created.seed ensureInit
    (adversary created.publicIdentity created.server.server.metadata.sender) (initial created runtime)
    (initial_good created runtime) result supported

/-- Run the source supplied/generated Server constructor before the complete table-backed raw schedule. Constructor failure returns the original runtime and no initialized protocol result. -/
noncomputable def experiment (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (ensureInit : StateT A ProbComp Bool) (supplied : Option Pqxdh.Bytes)
    (adversary : PublicIdentity → Std.U64 → OracleComp PqxdhRegistrationSchedule.SurfaceSpec Result) (runtime : A) :
    ProbComp (ObservedOutcome KemSK Result A) := do
  let started ← (PqxdhLiveServerConstruction.construct setup.joint ensureInit 0 setup.serverKeyId supplied).run runtime
  match started.1 with
  | none => pure (none, started.2)
  | some created => (fun result => (some (created, result.1, result.2.1.2, result.2.2), result.2.1.1)) <$>
      (tableExecute setup codec checks ensureInit adversary created started.2)

/-- Recover the original full native result from the actual current table view, keeping the initial Server identity, final adversary answer and runtime. -/
def sourceOutcome (outcome : ObservedOutcome KemSK Result A) :
    Option (PqxdhLiveServerConstruction.Created Unit × (Result × PqxdhRegistrationSchedule.State KemSK)) × A :=
  (outcome.1.map (fun result => (result.1, result.2.1, install result.2.2.1 result.2.2.2.current)), outcome.2)

/-- The entire table-backed experiment is the original constructor and raw adaptive source execution under the complete reconstructed-state projection. Optional failure and all reached primitive/runtime work remain exact. -/
theorem experiment_source (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (ensureInit : StateT A ProbComp Bool) (supplied : Option Pqxdh.Bytes)
    (adversary : PublicIdentity → Std.U64 → OracleComp PqxdhRegistrationSchedule.SurfaceSpec Result) (runtime : A) :
    sourceOutcome <$> experiment setup codec checks ensureInit supplied adversary runtime =
      PqxdhRegistrationSchedule.surfaceExperiment setup codec checks ensureInit supplied adversary runtime := by
  simp only [experiment, PqxdhRegistrationSchedule.surfaceExperiment, map_bind]
  apply bind_congr
  rintro ⟨created, initialized⟩
  cases created <;> simp only [map_pure, sourceOutcome, Option.map_none]
  rw [← execute_source]
  simp only [Functor.map_map, sourceOutcome, Option.map_some, restore]

/-- Exact program projection transports every interpreted predicate query certificate. Reconstructing and clearing the redundant map adds no oracle calls and removes none of the actual source work. -/
theorem experiment_bound_iff (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (ensureInit : StateT A ProbComp Bool) (supplied : Option Pqxdh.Bytes)
    (adversary : PublicIdentity → Std.U64 → OracleComp PqxdhRegistrationSchedule.SurfaceSpec Result)
    (runtime : A) (predicate : unifSpec.Domain → Prop) [DecidablePred predicate] (cap : Nat) :
    (experiment setup codec checks ensureInit supplied adversary runtime).IsQueryBoundP predicate cap ↔
      (PqxdhRegistrationSchedule.surfaceExperiment setup codec checks ensureInit supplied adversary runtime).IsQueryBoundP predicate cap := by
  rw [← experiment_source setup codec checks ensureInit supplied adversary runtime, isQueryBoundP_map_iff]

/-- The complete nine-class source bill applies to the table-backed dispatcher, including initial Server construction, rejected requests and every reached runtime/KEM callback. -/
theorem experiment_uniform (setup : Setup baseSpec KemSK) (codec : Codec Reader Response) (checks : Checks)
    (caps : PqxdhServerAuthSourceCosts.KemCaps) (bounded : PqxdhServerAuthSourceCosts.KemBound setup caps)
    (ensureInit : StateT A ProbComp Bool) (qInit : Nat)
    (initBound : ∀ runtime, (ensureInit.run runtime).IsTotalQueryBound qInit)
    (supplied : Option Pqxdh.Bytes)
    (adversary : PublicIdentity → Std.U64 → OracleComp PqxdhRegistrationSchedule.SurfaceSpec Result)
    (budget : Fin 9 → Nat)
    (certified : ∀ identity keyId, PqxdhRegistrationSchedule.UniformBounded (adversary identity keyId) budget)
    (runtime : A) :
    (experiment setup codec checks ensureInit supplied adversary runtime).IsTotalQueryBound
      (qInit + (if supplied.isNone then 32 else 0) +
        ∑ kind, PqxdhRegistrationSchedule.uniformCost caps qInit kind * budget kind) := by
  simpa only [← experiment_source setup codec checks ensureInit supplied adversary runtime,
    IsTotalQueryBound, isQueryBound_map_iff] using
    PqxdhRegistrationSchedule.surfaceExperiment_uniform setup codec checks caps bounded ensureInit qInit
      initBound supplied adversary budget certified runtime

/-- No complete initialized execution retains a second current-token map: every reached callback clears it, while the actual historical table is retained for the next dispatch. -/
theorem execute_cleared (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (ensureInit : StateT A ProbComp Bool)
    (adversary : PublicIdentity → Std.U64 → OracleComp PqxdhRegistrationSchedule.SurfaceSpec Result)
    (created : PqxdhLiveServerConstruction.Created Unit) (runtime : A)
    (result : Result × State KemSK A)
    (supported : result ∈ support (tableExecute setup codec checks ensureInit adversary created runtime)) :
    result.2.1.2.shared.2.pending = fun _ => none := by
  exact simulateQ_run_preserves_inv_of_query (handler setup codec checks created.seed ensureInit)
    (fun state => state.1.2.shared.2.pending = fun _ => none)
    (fun query before _ after reached => handler_cleared setup codec checks created.seed ensureInit query before after reached)
    (adversary created.publicIdentity created.server.server.metadata.sender) (initial created runtime) rfl result supported

/-- The full source constructor and adaptive schedule supply allocated unique tables and an empty redundant map on every successful initialized result. No initial archive or callback-success premise is required. -/
theorem experiment_good (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (ensureInit : StateT A ProbComp Bool) (supplied : Option Pqxdh.Bytes)
    (adversary : PublicIdentity → Std.U64 → OracleComp PqxdhRegistrationSchedule.SurfaceSpec Result)
    (runtime afterRuntime : A) (created : PqxdhLiveServerConstruction.Created Unit)
    (answer : Result) (state : PqxdhRegistrationSchedule.State KemSK) (table : PendingTable)
    (supported : (some (created, answer, state, table), afterRuntime) ∈ support
      (experiment setup codec checks ensureInit supplied adversary runtime)) :
    Good ((afterRuntime, state), table) ∧ state.shared.2.pending = (fun _ => none) := by
  simp only [experiment, mem_support_bind_iff] at supported
  rcases supported with ⟨⟨_ | started, initialized⟩, _, reached⟩
  all_goals simp [Set.mem_image] at reached
  exact ⟨execute_good setup codec checks ensureInit adversary started initialized
    (answer, (afterRuntime, state), table) reached.1,
    execute_cleared setup codec checks ensureInit adversary started initialized
      (answer, (afterRuntime, state), table) reached.1⟩

/-- The actual table-backed experiment's source projection returns a pending token exactly when its immutable numeric row exists and its used marker is absent. Equal token bytes at different indices are unrestricted. -/
theorem experiment_available (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (ensureInit : StateT A ProbComp Bool) (supplied : Option Pqxdh.Bytes)
    (adversary : PublicIdentity → Std.U64 → OracleComp PqxdhRegistrationSchedule.SurfaceSpec Result)
    (runtime afterRuntime : A) (created : PqxdhLiveServerConstruction.Created Unit)
    (answer : Result) (state : PqxdhRegistrationSchedule.State KemSK) (table : PendingTable)
    (supported : (some (created, answer, state, table), afterRuntime) ∈ support
      (experiment setup codec checks ensureInit supplied adversary runtime))
    (index : Nat) (token : PqxdhServerRelatedRootConsumer.Returned) :
    (restore ((afterRuntime, state), table)).2.shared.2.pending index = some token ↔
      (index, token) ∈ table.rows ∧ index ∉ table.used := by
  exact current_row table index token
    (experiment_good setup codec checks ensureInit supplied adversary runtime afterRuntime created answer state table supported).1.2

/-- Every live table list has at most one entry per original accept attempt. This bounds bookkeeping size while leaving its local lookup and append runtime explicit. -/
theorem experiment_lengths (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (ensureInit : StateT A ProbComp Bool) (supplied : Option Pqxdh.Bytes)
    (adversary : PublicIdentity → Std.U64 → OracleComp PqxdhRegistrationSchedule.SurfaceSpec Result)
    (runtime afterRuntime : A) (created : PqxdhLiveServerConstruction.Created Unit)
    (answer : Result) (state : PqxdhRegistrationSchedule.State KemSK) (table : PendingTable)
    (supported : (some (created, answer, state, table), afterRuntime) ∈ support
      (experiment setup codec checks ensureInit supplied adversary runtime)) :
    table.rows.length ≤ state.shared.2.sessions ∧ table.used.length ≤ state.shared.2.sessions := by
  exact table_lengths table state.shared.2.sessions
    (experiment_good setup codec checks ensureInit supplied adversary runtime afterRuntime created answer state table supported).1.1
    (experiment_good setup codec checks ensureInit supplied adversary runtime afterRuntime created answer state table supported).1.2

/-- The complete chronological public request/reply journal is preserved by the initialized table-backed experiment, together with the original result, constructor, runtime and reconstructed native state. -/
theorem journal_source (setup : Setup baseSpec KemSK) (codec : Codec Reader Response)
    (checks : Checks) (ensureInit : StateT A ProbComp Bool) (supplied : Option Pqxdh.Bytes)
    (adversary : PublicIdentity → Std.U64 → OracleComp PqxdhRegistrationSchedule.SurfaceSpec Result)
    (runtime : A) :
    sourceOutcome <$> experiment setup codec checks ensureInit supplied
      (fun identity sender => PqxdhRegistrationCells.journal (adversary identity sender)) runtime =
      PqxdhRegistrationSchedule.surfaceExperiment setup codec checks ensureInit supplied
        (fun identity sender => PqxdhRegistrationCells.journal (adversary identity sender)) runtime := by
  exact experiment_source setup codec checks ensureInit supplied _ runtime

end BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher

/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.restore_clear' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.restore_clear
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.restore_valid' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.restore_valid
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.prepared_valid' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.prepared_valid
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.handler_cleared' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.handler_cleared
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.handler_good' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.handler_good
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.handler_source' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.handler_source
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.program_source' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.program_source
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.program_good' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.program_good
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.initial_good' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.initial_good
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.initial_restore' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.initial_restore
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.execute_source' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.execute_source
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.execute_good' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.execute_good
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.experiment_source' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.experiment_source
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.experiment_bound_iff' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.experiment_bound_iff
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.experiment_uniform' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.experiment_uniform
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.execute_cleared' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.execute_cleared
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.experiment_good' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.experiment_good
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.experiment_available' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.experiment_available
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.experiment_lengths' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.experiment_lengths
/-- info: 'BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.journal_source' depends on axioms: [propext,
 Classical.choice,
 Quot.sound] -/
#guard_msgs in
#print axioms BeaconcryptCore.Computational.PqxdhRegistrationTableDispatcher.journal_source
