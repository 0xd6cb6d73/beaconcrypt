import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import shutil

from source_hashes import source_hashes

work = Path("/home/user/worktrees/beaconcrypt-row-burst-profile")
root = Path(__file__).resolve().parent
os.chdir(work)
os.environ["PATH"] = ":".join(
    [
        "/tmp/bc-arc-scratch/row-persistence-20261025",
        "/home/user/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin",
        "/home/user/.cargo/bin",
        "/nix/store/9wyldz5qids294k9h5qcg1f72i52jidi-gnumake-4.4.1/bin",
        os.environ["PATH"],
    ]
)
os.environ.update(
    RUSTFLAGS="-C linker-features=-lld",
    CARGO_BUILD_JOBS="3",
    CARGO_PROFILE_RELEASE_DEBUG="1",
    CARGO_PROFILE_RELEASE_STRIP="false",
    CARGO_TARGET_DIR="/tmp/bc-arc-scratch/core-row-merge/target",
)
if subprocess.check_output(["git", "status", "--porcelain"], text=True).strip():
    raise RuntimeError("release source must be committed and clean")
commit = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
before = source_hashes(work)
command = [
    "cargo",
    "build",
    "--locked",
    "--release",
    "-p",
    "beaconcrypt",
    "--example",
    "persistence_bench",
]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root / "release-build.log").open("xb") as output:
    subprocess.run(command, stdout=output, stderr=subprocess.STDOUT, check=True)
if (
    before != source_hashes(work)
    or commit
    != subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
):
    raise RuntimeError("release source changed during build")
binary = root / "persistence_bench"
shutil.copy2(Path(os.environ["CARGO_TARGET_DIR"]) / "release/examples/persistence_bench", binary)
receipt = dict(
    source_commit=commit,
    source_sha256=before,
    command=command,
    started=started,
    finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    binary=str(binary),
    binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
    rustc=subprocess.check_output(["rustc", "-Vv"], text=True),
    cargo=subprocess.check_output(["cargo", "--version"], text=True).strip(),
    environment={
        key: os.environ[key]
        for key in ("RUSTFLAGS", "CARGO_BUILD_JOBS", "CARGO_TARGET_DIR", "CARGO_PROFILE_RELEASE_DEBUG", "CARGO_PROFILE_RELEASE_STRIP")
    },
)
with (root / "build-receipt.json").open("x") as output:
    json.dump(receipt, output, indent=2)
    output.write("\n")
print(
    json.dumps(
        {key: receipt[key] for key in ("source_commit", "binary", "binary_sha256")},
        indent=2,
    )
)
